# 📋 Deployment Checklist - Tender Management System

## Pre-Deployment Requirements

### ✅ Hosting Environment
- [ ] cPanel shared hosting with Node.js support
- [ ] Node.js version 18+ available
- [ ] PostgreSQL 13+ database available
- [ ] SSH access (recommended) or File Manager access
- [ ] npm/npx commands available

### ✅ Domain & SSL
- [ ] Domain pointed to hosting server
- [ ] SSL certificate installed (recommended)
- [ ] DNS propagation completed

## Step-by-Step Deployment

### 1. File Upload ⬆️
- [ ] Extract deployment-package.zip to local computer
- [ ] Upload all files to `public_html` directory via:
  - [ ] cPanel File Manager, OR
  - [ ] FTP/SFTP client, OR
  - [ ] SSH with scp/rsync
- [ ] Verify folder structure is maintained:
  ```
  public_html/
  ├── server/
  ├── client/
  ├── shared/
  ├── deployment/
  ├── server.js
  ├── package.json
  └── ...
  ```

### 2. Dependencies Installation 📦
- [ ] Access terminal/SSH or use cPanel Terminal
- [ ] Navigate to public_html: `cd public_html`
- [ ] Install dependencies: `npm install`
- [ ] Verify tsx installation: `npx tsx --version`
- [ ] If tsx fails: `npm install tsx --save`

### 3. Database Setup 🗄️
- [ ] Access cPanel → PostgreSQL Databases
- [ ] Create new database (note the name)
- [ ] Create database user (note username/password)
- [ ] Assign user to database with ALL PRIVILEGES
- [ ] Access phpPGAdmin or use psql
- [ ] Open `database_setup_postgresql13.sql`
- [ ] Copy entire content and execute in database
- [ ] Verify 19 tables created successfully
- [ ] Test connection: `psql -h localhost -U username -d dbname`

### 4. Environment Configuration ⚙️
- [ ] Copy `.env.example` to `.env`
- [ ] Update database credentials:
  ```bash
  DATABASE_URL=postgresql://username:password@localhost:5432/dbname
  PGHOST=localhost
  PGPORT=5432
  PGUSER=your_db_username
  PGPASSWORD=your_db_password
  PGDATABASE=your_db_name
  ```
- [ ] Set environment:
  ```bash
  NODE_ENV=production
  PORT=5000
  ```
- [ ] Generate secure secrets:
  ```bash
  JWT_SECRET=your_32_char_random_string
  SESSION_SECRET=your_32_char_random_string
  ```
- [ ] Update domain settings:
  ```bash
  CORS_ORIGIN=https://yourdomain.com
  ALLOWED_ORIGINS=https://yourdomain.com,https://www.yourdomain.com
  ```

### 5. Application Startup 🚀
- [ ] Test deployment: `node test-deployment.js`
- [ ] Start application: `node server.js`
- [ ] If startup fails, try alternatives:
  - [ ] `node start-production.js`
  - [ ] `npx tsx server/index.ts`
  - [ ] `node --loader tsx/esm server/index.ts`
- [ ] Check for error messages and resolve

### 6. Process Management 🔄
- [ ] Install PM2 for process management: `npm install -g pm2`
- [ ] Start with PM2: `pm2 start server.js --name tender-app`
- [ ] Set startup script: `pm2 startup`
- [ ] Save configuration: `pm2 save`
- [ ] Verify process running: `pm2 status`

## Verification Tests

### 🔍 Basic Functionality
- [ ] Visit your domain in browser
- [ ] Application loads without errors
- [ ] Login page displays correctly
- [ ] Test admin login: `admin` / `admin123`
- [ ] Dashboard loads successfully
- [ ] Navigation menu works
- [ ] All Tenders page loads
- [ ] Settings menu visible only for admin users

### 🔍 Database Connectivity
- [ ] User login successful
- [ ] Dashboard data displays
- [ ] Tender data loads
- [ ] User creation works (admin only)
- [ ] File uploads work
- [ ] Activities log records events

### 🔍 Performance Tests
- [ ] Page load time < 3 seconds
- [ ] File uploads work smoothly
- [ ] Database queries respond quickly
- [ ] Memory usage reasonable
- [ ] No memory leaks over time

## Post-Deployment Tasks

### 🔒 Security Setup
- [ ] Change all default passwords:
  - [ ] Admin: `admin` / `admin123` → new secure password
  - [ ] Kaustubh: `kn@starinxs.com` / `admin123` → new password
  - [ ] Poonam: `poonam.amale` / `admin123` → new password
- [ ] Enable HTTPS redirect in `.htaccess` (if SSL available)
- [ ] Verify security headers working
- [ ] Test file upload restrictions
- [ ] Review error logs for security issues

### 📊 Monitoring Setup
- [ ] Set up log rotation for application logs
- [ ] Configure database backup schedule
- [ ] Monitor disk space usage
- [ ] Set up uptime monitoring
- [ ] Configure error alerting

### 🎯 Optional Enhancements
- [ ] Configure SendGrid for email notifications
- [ ] Set up Anthropic AI for document analysis
- [ ] Enable Stripe for payment processing
- [ ] Configure CDN for static assets
- [ ] Set up automated backups

## Troubleshooting Guide

### ❌ Server Won't Start
**Symptoms**: Error on `node server.js`
**Solutions**:
1. Check Node.js version: `node --version`
2. Install tsx: `npm install tsx`
3. Try safe startup: `node start-production.js`
4. Check logs for specific errors

### ❌ Database Connection Failed
**Symptoms**: "Database connection failed" error
**Solutions**:
1. Verify credentials in `.env`
2. Test connection: `psql -h localhost -U user -d db`
3. Check PostgreSQL service: `service postgresql status`
4. Verify user permissions on database

### ❌ Module Not Found
**Symptoms**: "Cannot find module" errors
**Solutions**:
1. Run: `npm install`
2. Check file permissions
3. Verify folder structure intact
4. Try: `npm cache clean --force && npm install`

### ❌ Permission Denied
**Symptoms**: File/folder permission errors
**Solutions**:
1. Fix permissions: `chmod 755 server.js`
2. Check folder ownership
3. Verify upload directory writable: `chmod 777 uploads`

## Support Contacts

**Technical Issues**:
- Check error logs first
- Review this checklist
- Test individual components
- Provide specific error messages when seeking help

**Deployment Success Indicators**:
✅ Application starts without errors  
✅ Database connects successfully  
✅ Admin login works  
✅ Dashboard displays data  
✅ All core features functional  

---

**Deployment Package Version**: January 2025  
**Last Updated**: Compatible with cPanel hosting, PostgreSQL 13+, Node.js 18+