// Import directly from the user-context file
import { useUser } from '@/user-context';

// Export the useUser hook
export { useUser };