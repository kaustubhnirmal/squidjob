# cPanel Node.js Deployment Guide

## Issue Analysis
Your web server is showing a directory listing instead of serving the application. This means:
1. Node.js application isn't running
2. Web server configuration needs adjustment
3. Build files need to be generated

## Solution Steps

### Step 1: Check Node.js Support
**In cPanel:**
1. Look for **"Node.js App"** or **"Node.js Selector"** in cPanel
2. If not available, contact your hosting provider to enable Node.js support
3. Most modern cPanel hosting supports Node.js 14+

### Step 2: Build the Application
Run these commands in your project directory:

```bash
# Install dependencies
npm install

# Build the application for production
npm run build
```

This creates:
- `dist/` folder with compiled server code
- `dist/client/` folder with built frontend files

### Step 3: Configure Node.js App in cPanel

**If Node.js App is available:**
1. Go to **Node.js App** in cPanel
2. Click **"Create Application"**
3. Configure:
   - **Node.js Version**: 18+ (recommended)
   - **Application Mode**: Production
   - **Application Root**: `/public_html/` (or your domain folder)
   - **Application URL**: Your domain
   - **Application Startup File**: `server.js`
4. Click **"Create"**

### Step 4: Upload Files Correctly

**File Structure on Server:**
```
public_html/
├── dist/
│   ├── index.js          # Built server
│   └── client/           # Built frontend
├── uploads/              # File uploads directory
├── server.js             # Production entry point
├── package.json          # Dependencies
├── .htaccess            # Apache configuration (if needed)
└── .env                 # Environment variables
```

### Step 5: Environment Variables

**Create `.env` file on server:**
```bash
NODE_ENV=production
PORT=5000
DATABASE_URL=postgresql://username:password@localhost:5432/database_name
JWT_SECRET=your-super-secret-jwt-key-here

# SMTP Configuration
SMTP_HOST=smtp.squidjob.com
SMTP_PORT=465
SMTP_USER=your-email-username
SMTP_PASS=your-email-password
SMTP_SECURE=true
```

### Step 6: Alternative Deployment (if Node.js App not available)

**Option A: Static + API Hosting**
If Node.js isn't supported, you can:
1. Host frontend as static files
2. Deploy backend on a Node.js service (Heroku, Railway, etc.)
3. Update API endpoints in frontend

**Option B: PHP Bridge (Advanced)**
Create a PHP script that proxies requests to your Node.js server running on a different port.

### Step 7: Manual Server Start

**If using SSH access:**
```bash
# Navigate to your application directory
cd /home/username/public_html

# Install dependencies
npm install --production

# Start the application
npm start

# Or start with PM2 for persistence
npm install -g pm2
pm2 start dist/index.js --name "tender-app"
pm2 startup
pm2 save
```

### Step 8: Verification

**Test your deployment:**
1. Visit your domain - should show the landing page
2. Check `/api/health` endpoint
3. Try logging in with admin credentials
4. Test file uploads

### Troubleshooting

**Common Issues:**

1. **Directory Listing Still Showing**
   - Node.js app not running
   - Wrong startup file path
   - Missing build files

2. **500 Internal Server Error**
   - Check error logs in cPanel
   - Verify environment variables
   - Check database connection

3. **API Endpoints Not Working**
   - Verify Node.js app is running
   - Check port configuration
   - Review .htaccess rules

4. **Database Connection Failed**
   - Verify DATABASE_URL format
   - Check PostgreSQL credentials
   - Ensure database exists

### File Permissions
Set correct permissions:
```bash
chmod 755 uploads/
chmod 644 package.json
chmod 644 .env
chmod 755 dist/
```

### Performance Optimization
1. **Enable Gzip compression** in cPanel
2. **Set up caching** for static assets
3. **Use CDN** for better global performance
4. **Monitor resource usage** in cPanel metrics

## Quick Fix Commands

**Build and prepare for upload:**
```bash
# Local machine
npm run build
zip -r deployment.zip dist/ uploads/ package.json server.js .htaccess .env.example

# Upload deployment.zip to server and extract
```

**Essential files to upload:**
- `dist/` (entire folder)
- `package.json`
- `server.js`
- `.env` (with your credentials)
- `.htaccess` (if Apache)

## Success Indicators
✅ Domain shows landing page (not directory listing)
✅ Login page accessible
✅ API endpoints respond
✅ File uploads work
✅ Database operations successful

Contact your hosting provider if Node.js support isn't available or if you need assistance with configuration.