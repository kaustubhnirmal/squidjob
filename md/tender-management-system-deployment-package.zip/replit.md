# Tender Management System

## Overview

This is a comprehensive tender management system built with Node.js, Express, React, and PostgreSQL. The system provides end-to-end tender lifecycle management including tender import, tracking, assignment, document management, financial approvals, and reporting capabilities.

## System Architecture

### Frontend Architecture
- **React 18** with TypeScript for the client-side application
- **Vite** as the build tool and development server
- **TailwindCSS** with shadcn/ui components for styling
- **Wouter** for client-side routing
- **React Query** for server state management and caching
- Component-based architecture with reusable UI components

### Backend Architecture
- **Express.js** server with TypeScript
- RESTful API endpoints for all business operations
- Modular service layer architecture
- Middleware for request logging and error handling
- File upload handling with multer

### Data Storage Solutions
- **PostgreSQL** as the primary database
- **Drizzle ORM** for database operations and schema management
- **Neon Database** as the PostgreSQL provider
- Database migrations managed through Drizzle Kit

## Key Components

### Authentication & Authorization
- **Secure JWT-based authentication** with 24-hour token expiry
- **bcrypt password hashing** with 12 salt rounds for maximum security
- **Role-based access control (RBAC)** system with admin-only endpoint protection
- **Input validation and sanitization** on all user inputs
- **Rate limiting** to prevent brute force attacks
- **Security headers** including CSP, HSTS, and anti-clickjacking protection
- User management with departments and designations
- Permission-based route protection with proper authorization checks

### Tender Management
- Complete tender lifecycle from import to completion
- Multiple tender statuses: New, Live, In-Process, Submitted, Awarded, etc.
- Tender assignment and team collaboration
- Document attachment and management
- AI-powered insights and eligibility criteria generation

### Document Processing
- PDF, Excel, and CSV file import capabilities
- Document parsing and data extraction
- File storage and retrieval system
- Document briefcase for organized file management

### Financial Management
- Financial approval workflows
- EMD (Earnest Money Deposit) tracking
- Budget and cost management
- Purchase order processing

### Reporting & Analytics
- MIS reports for sales and finance
- Dashboard with key performance indicators
- Export functionality for Excel reports
- User activity tracking and login logs

## Data Flow

1. **Tender Import**: Users upload tender documents (PDF/Excel/CSV) which are processed and parsed
2. **Tender Assignment**: Admin users assign tenders to team members
3. **Processing**: Assigned users work on tenders, update status, and attach documents
4. **Financial Approval**: Finance team handles approval workflows
5. **Submission**: Completed tenders are submitted through the system
6. **Tracking**: System tracks tender progress and generates reports

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL database connectivity (can be replaced with standard pg client for AlmaLinux deployments)
- **@anthropic-ai/sdk**: AI services for document analysis
- **@sendgrid/mail**: Email notification services
- **@stripe/stripe-js**: Payment processing capabilities
- **multer**: File upload handling
- **pdf-parse**: PDF document parsing
- **xlsx**: Excel file processing

### UI Dependencies
- **@radix-ui/react-***: Comprehensive UI component library
- **@tanstack/react-query**: Server state management
- **tailwindcss**: Utility-first CSS framework
- **lucide-react**: Icon library

## Deployment Strategy

The application is configured for deployment on Replit with the following setup:

- **Development**: `npm run dev` starts the development server with hot reloading
- **Build**: `npm run build` creates production builds for both client and server
- **Production**: `npm run start` runs the production server
- **Database**: Automatic PostgreSQL provisioning through Replit modules
- **Auto-scaling**: Configured for automatic scaling based on demand

### Environment Configuration
- Database URL automatically configured through Replit
- Optional API keys for SendGrid (email) and OpenAI (AI features)
- File upload directory automatically created and managed

## Changelog

Changelog:
- January 22, 2025: **COMPREHENSIVE CPANEL DEPLOYMENT FIX** - Resolved critical deployment issues preventing production deployment:
  * **Fixed Module Not Found Error**: Updated server.js to handle TypeScript files properly with intelligent fallback mechanisms
  * **PostgreSQL 13.20 Compatibility**: Created database_setup_postgresql13.sql with pure DDL statements instead of pg_dump format
  * **Multiple Startup Methods**: Added start-production.js as alternative startup script with comprehensive error handling
  * **Complete Documentation**: Created CPANEL_DEPLOYMENT_SOLUTION_GUIDE.md with step-by-step deployment instructions
  * **Settings Menu Security**: Implemented double-layer protection to completely hide Settings menu from non-admin users
  * **Enhanced Error Recovery**: Added fallback chains for maximum hosting environment compatibility
  * **Production Ready**: Application now successfully deployable on cPanel shared hosting with PostgreSQL 13.20
  * **Database Schema**: Complete 19-table schema with initial admin users, permissions, and sample data
  * **Security Features**: Default admin credentials with bcrypt hashing, role-based access control fully functional
- July 21, 2025: **FIXED USER CREATION AUTHENTICATION ISSUE** - Resolved 401 Unauthorized errors preventing new user creation:
  * **Root Cause**: User Management component was calling apiRequest with incorrect parameter order
  * **Parameter Fix**: Updated apiRequest calls from `apiRequest("POST", "/api/users", data)` to `apiRequest("/api/users", {method: "POST", body: JSON.stringify(data)})`
  * **Authentication Headers**: Ensured proper x-user-id and Authorization headers are sent with user creation requests
  * **Admin Verification**: Confirmed admin users (role: "Admin") can successfully create new users through the interface
  * **Complete Functionality**: User creation modal now works properly with form validation and database integration
  * **Error Resolution**: Eliminated "Authentication required" 401 errors during user submission
  * **Backend Integration**: Verified requireAdmin middleware correctly validates admin permissions for user creation
  * **Testing Verified**: Successfully tested user creation with admin user (ID: 5, Kaustubh Nirmal)
- July 21, 2025: **UNIVERSAL STAR AND INTEREST FUNCTIONALITY FOR ALL USERS** - Enhanced star/interest system to work properly for all authenticated users:
  * **User-Specific Star/Interest**: Fixed cache key synchronization between All Tenders page and action buttons
  * **Proper Authentication**: Updated action buttons to use direct fetch requests with x-user-id headers matching backend expectations
  * **Independent User Data**: Each user now maintains their own star and interest lists without interference
  * **Real-time Cache Updates**: Cache invalidation and updates now work correctly with user-specific keys
  * **Consistent Functionality**: Star and interest actions work identically across All Tenders and individual tender pages
  * **Backend Integration**: Verified backend endpoints properly handle all users through header-based authentication
  * **Cross-User Testing**: Confirmed functionality works independently for different users (User 3, 4, 5 tested)
  * **Database Relationships**: User-tender relationships correctly created and managed per user
- July 21, 2025: **FIXED TENDER ASSIGNMENT NOTIFICATIONS SYSTEM** - Resolved duplicate assignment activities and display issues:
  * **Single Activity Creation**: Eliminated duplicate notifications by creating only one assignment activity instead of separate "assign" and "assigned" activities
  * **Fixed Tender ID Display**: Assignment notifications now show proper tender reference numbers instead of "N/A"
  * **Corrected Assignor Information**: "Assign By" field now shows the actual user who assigned the tender instead of incorrect user data
  * **Enhanced Activity Format**: Assignment activities display complete information in requested format:
    - Tender Assign to: [assignee name]
    - Tender ID: [tender reference number]  
    - Assign By: [assignor name]
    - Assign Date & Time: [DD-MM-YYYY, HH:MM format]
    - Submission Date: [DD-MM-YYYY format]
  * **Streamlined Database Logic**: Updated assignment activity creation to use single "tender_assignment" action type
  * **Improved Data Structure**: Enhanced metadata storage to ensure proper tender reference numbers and user information
  * **Real-time Updates**: Assignment activities appear instantly in Today's Activity widget with accurate information
  * **Professional Display**: Green color indicator for assignment activities with clear, structured information layout
- July 20, 2025: **ALMALINUX 9 POSTGRESQL COMPATIBILITY** - Added comprehensive PostgreSQL downgrade support:
  * **PostgreSQL Version Support**: Added compatibility for PostgreSQL 12, 13, and 14 (recommended for AlmaLinux 9)
  * **Automated Setup Script**: Created `deployment/almalinux-setup.sh` for one-command PostgreSQL 13 installation
  * **Local Database Configuration**: Added `server/db-local.ts` optimized for local PostgreSQL connections
  * **Environment Templates**: Created `.env.almalinux` with production-ready configuration examples
  * **Compatibility Documentation**: Comprehensive guides for PostgreSQL version selection and migration
  * **Connection Pool Optimization**: Adjusted pool settings for stability on AlmaLinux 9 environment
  * **SSL Configuration**: Smart SSL detection that works with both cloud and local PostgreSQL setups
  * **Migration Path**: Step-by-step instructions for migrating from Neon Database to local PostgreSQL
  * **Performance Tuning**: PostgreSQL configuration optimized for AlmaLinux 9 server environment
- July 18, 2025: **UNIVERSAL PDF COMPRESSION SYSTEM** - Created robust compression system that works consistently across all environments:
  * **Environment Detection**: Added automatic detection of Ghostscript availability on the system
  * **Fallback Compression**: When Ghostscript is not available (local environments), system falls back to enhanced pdf-lib compression
  * **Consistent Results**: Universal compression service provides predictable results regardless of environment
  * **Method Reporting**: Compression results now include method used (ghostscript/pdf-lib/hybrid) for transparency
  * **Error Handling**: Added comprehensive error handling with automatic fallback to simple compression if primary methods fail
  * **Local Development Fix**: Resolved issue where compression showed actual file sizes instead of compressed versions in local environments
  * **Performance Optimization**: Maintained fast compression speeds while ensuring consistent compression ratios across environments
  * **Backward Compatibility**: All existing compression endpoints continue to work with improved reliability
- July 18, 2025: **FIXED JWT TOKEN EXPIRATION AUTHENTICATION ISSUE** - Resolved critical authentication problem preventing tender response submissions:
  * **Root Cause**: JWT tokens were expiring after 24 hours, causing "Failed to submit response" errors during tender submission
  * **Token Refresh System**: Added automatic token refresh mechanism that detects expired tokens and requests new ones
  * **Seamless Authentication**: Frontend now automatically refreshes tokens when receiving 401 errors from expired tokens
  * **Enhanced apiRequest Function**: Updated to handle token refresh with retry logic for failed requests
  * **Backward Compatibility**: Maintained both JWT authentication and x-user-id header support for existing functionality
  * **Refresh Endpoint**: Added `/api/auth/refresh` endpoint that safely handles expired tokens and generates new ones
  * **Auto-Redirect**: System automatically redirects to login page if token refresh fails
  * **Storage Updates**: Enhanced localStorage management to store and update JWT tokens alongside user data
  * **Query Function Updates**: Updated React Query functions to handle token refresh for data fetching operations
  * **Authentication Middleware**: Enhanced server-side authentication to properly handle token expiration scenarios
- July 18, 2025: **COMPREHENSIVE DOWNLOAD FILENAME STANDARDIZATION** - Implemented universal filename fix across all download endpoints:
  * **Root Cause Resolution**: Frontend JavaScript was overriding server filenames with hardcoded patterns like "original_response_X.pdf"
  * **Server-Side Enhancement**: Added filename sanitization to remove spaces and special characters for better browser compatibility
  * **Content-Disposition Headers**: Enhanced all server endpoints to send proper Content-Disposition headers with cleaned filenames
  * **Frontend Universal Fix**: Updated all download handlers to extract and use actual filenames from server response headers
  * **Comprehensive Coverage**: Fixed downloads across all modules:
    - Tender response downloads (original and compressed)
    - Checklist document downloads
    - Bid results PDF downloads
    - Tender results PDF downloads
    - Document brief case downloads
    - Generated checklist response downloads
  * **Example Fix**: "Test cert" response now downloads as "Testcert.pdf" instead of "original_response_106.pdf"
  * **Cache Prevention**: Added no-cache headers to prevent browser filename caching issues
  * **Debug Logging**: Enhanced logging to track filename processing and verify correct Content-Disposition headers
  * **Backward Compatibility**: Maintained fallback filenames for any edge cases where server headers might not be available
- July 17, 2025: **OPTIMIZED TENDER RESPONSE DOWNLOADS** - Enhanced download performance and file naming for tender checklist responses:
  * **Faster Downloads**: Optimized file streaming with 64KB buffer size for improved download speeds (target: under 10 seconds)
  * **Proper File Names**: Fixed download file names to use original response names without "_Compiled" suffix
  * **Performance Logging**: Added download start/end logging to monitor file transfer performance
  * **Optimized Caching**: Changed cache headers to allow 1-hour caching for better performance
  * **Buffer Optimization**: Increased read stream buffer size from default to 64KB for faster file transfers
  * **Maintained PDF Extension**: Ensures downloaded files always have .pdf extension for proper file handling
- July 17, 2025: **INSTANT TAB SWITCHING WITH PAGINATION FOR MY TENDERS** - Implemented preloaded tab data and pagination for My Tenders page:
  * **All Data Preloading**: Created `/api/users/:id/assigned-tenders/all` endpoint that fetches all assigned tenders data at once for instant tab switching
  * **Client-Side Filtering**: Tab switching now handled client-side with instant filtering based on assignment date, tender status, and interest status
  * **Pagination System**: Added comprehensive pagination with 10 items per page default, configurable (10, 20, 50, 100 options)
  * **Smart Pagination Controls**: Includes First, Previous, Next, Last buttons with intelligent page number display (shows 5 pages max)
  * **Performance Optimization**: Eliminated server requests on tab changes, data cached for 5 minutes with 10-minute garbage collection
  * **Tab Count Calculation**: Real-time tab counts calculated from complete dataset for accurate badges
  * **Reset Logic**: Automatically resets to page 1 when switching tabs or performing searches
  * **Purple Theme Integration**: Active page numbers use purple theme (#7c3aed) matching website design
  * **Responsive Design**: Pagination controls adapt to screen size with proper spacing and alignment
  * **Consistent UX**: My Tenders page now has same instant tab switching experience as All Tenders page
- July 17, 2025: **INSTANT TAB SWITCHING WITH PAGINATION** - Implemented preloaded tab data and pagination for All Tenders page:
  * **All Data Preloading**: Created `/api/tenders/all` endpoint that fetches all tenders data at once for instant tab switching
  * **Client-Side Filtering**: Tab switching now handled client-side with instant filtering based on dates, star status, and interest status
  * **Pagination System**: Added comprehensive pagination with 10 items per page default, configurable (10, 20, 50, 100 options)
  * **Smart Pagination Controls**: Includes First, Previous, Next, Last buttons with intelligent page number display (shows 5 pages max)
  * **Performance Optimization**: Eliminated server requests on tab changes, data cached for 5 minutes with 10-minute garbage collection
  * **Tab Count Calculation**: Real-time tab counts calculated from complete dataset for accurate badges
  * **Reset Logic**: Automatically resets to page 1 when switching tabs or performing searches
  * **Purple Theme Integration**: Active page numbers use purple theme (#7c3aed) matching website design
  * **Responsive Design**: Pagination controls adapt to screen size with proper spacing and alignment
  * **Tab Rename**: Changed "Fresh" tab to "All" tab showing all published tenders instead of just today's tenders
- July 17, 2025: **PDF EXPORT VISUAL ENHANCEMENTS** - Enhanced PDF export with table borders and copyright message:
  * **Table Border Implementation**: Added bordered table format for tender details section with grid lines and alternating row colors
  * **Copyright Message**: Added center-aligned copyright text "Copyright squidjob.com. All rights reserved 2025." in 6px font at bottom
  * **Logo Removal**: Removed distorted SquidJob logo from bottom right to prevent visual issues
  * **Improved Data Structure**: Converted tender details from plain text to structured table format with proper alignment
  * **Enhanced Space Calculation**: Adjusted space calculations to accommodate table format instead of individual text lines
  * **Professional Layout**: Maintained horizontal content display with improved visual hierarchy and readability
- July 17, 2025: **PDF EXPORT HEADER IMPROVEMENTS** - Enhanced PDF export with complete tender information display:
  * **Complete Tender ID Display**: Changed from displaying only last 7 digits to showing complete tender reference number
  * **RA Number Integration**: Added RA No in red color after tender ID when RA data is available
  * **Enhanced Header Layout**: Improved tender header with proper spacing and color coding
  * **Logo Optimization**: Fixed SquidJob logo dimensions and positioning to prevent distortion (20x15mm with proper aspect ratio)
  * **Data Field Cleanup**: Removed redundant RA No from row display since it's now prominently shown in header
  * **Corrected Field Mapping**: Fixed participant status and assigned user data to display actual database values
- July 17, 2025: **ENHANCED PDF EXPORT WITH OPTIMIZED LAYOUT** - Improved PDF export functionality with professional formatting and user experience enhancements:
  * **Subtle Export Buttons**: Changed export buttons to subtle grey design with download icons, showing only "Excel" and "PDF" text
  * **Progress Indicators**: Added loading states with spinning indicators and "Generating..." text when export is in progress
  * **Horizontal Content Layout**: Redesigned PDF to display tender details horizontally with all 16 specified fields
  * **Participant Details Table**: Added participant information in professional table format below each tender
  * **Logo Positioning**: Moved SquidJob logo to top-right corner in small greyscale format for professional appearance
  * **Portrait Orientation**: Maintained vertical page orientation with proper margins and spacing
  * **Smart Pagination**: Implemented intelligent page breaks that avoid cutting tender details in half, moving complete tenders to next page when needed
  * **Removed Currency Symbols**: Eliminated Rupee (₹) symbols from all amount fields in both Excel and PDF exports
  * **Enhanced Typography**: Used font size 7 for table content with proper word wrapping for text but preserved number formatting
  * **Professional Styling**: Applied consistent purple header theme with alternating row colors for better readability
  * **Consistent Button Design**: Updated All Tenders and My Tenders pages to use same subtle grey export buttons with download icons
- July 17, 2025: **EXCEL EXPORT ENHANCEMENTS** - Completed comprehensive Excel export functionality with real data integration:
  * **Enhanced Backend APIs**: Added comprehensive Excel export data gathering including L1 bidder detection, L1 amounts, RA numbers, and bid participants
  * **Real Data Integration**: Updated database queries to gather authentic data from multiple sources (tenders, assignments, bid participants, reverse auctions)
  * **Financial Value Formatting**: Changed financial fields (Estimate Value, L1 Amount, EMD Amount) to show "0" instead of "NA" when values are not available
  * **Automatic L1 Winner Detection**: System automatically identifies L1 winners from bid participants based on lowest bid amount
  * **RA Number Integration**: Includes latest Reverse Auction reference numbers from database
  * **Assigned Users Display**: Shows actual assigned user names instead of "System"
  * **15-Field Excel Export**: Complete implementation of all required fields (S.No, Tab Name, Days Left, Tender ID, Status, Assigned To, Authority, Estimate Value, EMD Amount, Published Date, Bid Start Date, Due Date, Location, RA No, L1 Bidder, L1 Amount)
  * **Duplicate Prevention**: Ensures unique tenders only in export files
  * **Cross-Tab Data Collection**: Collects data from all tabs for comprehensive reporting
  * **Both Page Support**: Functional Excel export on both All Tenders and My Tenders pages
- July 17, 2025: **SERVER PORTABILITY ENHANCEMENT** - Migrated all file paths from absolute to relative paths for cross-server compatibility:
  * **Database Path Migration**: Updated all existing database records to use relative paths (removed "/home/runner/workspace/" prefix)
  * **Normalized Path Storage**: All file paths now stored as relative paths (e.g., "uploads/file-123.pdf" instead of "/home/runner/workspace/uploads/file-123.pdf")
  * **Dynamic Path Resolution**: Enhanced path resolution utilities to work with any server directory structure
  * **Backward Compatibility**: System handles both existing absolute paths and new relative paths seamlessly
  * **Cross-Platform Support**: Database exports now work correctly when moved between different servers
  * **Updated Tables**: Fixed file paths in files, tender_responses, reverse_auctions, and task_allocations tables
  * **Verified Functionality**: Confirmed file uploads, downloads, and all document operations work correctly with new path system
  * **Health Check Fix**: Fixed health check endpoint to work with storage interface instead of direct database access
- July 16, 2025: **TENDER RESULTS PAGE WITH L1 WINNER DISPLAY** - Created comprehensive Tender Results page showing all participated tenders with published results:
  * **Card Layout Design**: Similar to All Tenders page with professional card design and responsive layout
  * **L1 Winner Information**: Special highlighted section showing L1 winner name and bid amount with trophy icon
  * **Tab Structure**: Four tabs (Fresh Results, Awarded Tenders, Lost Tenders, My Results) with dynamic counts
  * **Search & Filter**: Advanced filtering with search functionality and status-based filtering
  * **Status Indicators**: Color-coded status badges (Published, Awarded, Completed) with appropriate icons
  * **Winner Detection**: Automatic L1 winner determination from bid participants data with lowest bid amount
  * **Real Data Integration**: Uses actual bid participants and tender data from database
  * **Navigation Integration**: Direct links to tender details page from each card with proper routing
  * **Awarded Status Support**: Tenders marked as "Awarded" status appear under Awarded Tenders tab
  * **User Participation Filter**: Only shows tenders where current user has participated in bidding
- July 16, 2025: **COMPREHENSIVE ACTIVITY LOGGING FOR BID RESULTS** - Implemented complete activity logging system for all bid results operations:
  * **PDF Generation Logging**: Added logging for all PDF report downloads with user information, tender details, and generation timestamps
  * **Participant CRUD Logging**: Implemented detailed logging for create, update, and delete operations on bid participants with amount and status details
  * **Dialog Interaction Logging**: Added logging for bid results dialog open/close events with timestamps and user context
  * **Frontend Activity Logging**: Created POST endpoint `/api/tenders/:id/activities` for frontend activity logging with authentication
  * **Storage Method Enhancement**: Added `getBidParticipant` method to storage interface for proper participant data retrieval before operations
  * **Real Data Integration**: Fixed PDF generation to display actual end amounts and creator names from database instead of N/A values
  * **Field Name Corrections**: Updated PDF generation to use correct database field names (startAmount, endAmount, startDate, raNo, createdBy)
  * **User Information Lookup**: Enhanced RA data display with proper user name resolution from user database
  * **Complete Audit Trail**: All bid results page actions now generate comprehensive activity logs for full audit capability
- July 16, 2025: **ENHANCED BID RESULTS VALIDATION AND PDF STYLING** - Implemented comprehensive validation system and professional PDF formatting:
  * **Bid Amount Validation**: Added intelligent validation ensuring L1 < L2 < L3 bid amounts with real-time error messages
  * **Duplicate Participant Prevention**: Implemented validation to prevent adding same participant names multiple times
  * **Compact RA Data Display**: Removed Status and End Date & Time fields from RA section to save space and reduce dialog height
  * **Real Data Integration**: Replaced N/A values with actual data from tender details (EMD amount, deadline, current user info)
  * **Enhanced PDF Generation**: Added SquidJob logo in top-right corner, implemented professional table structure for tender and RA data
  * **Improved PDF Styling**: All fonts kept ≤11px, enhanced table borders, alternating row colors, and compact layout
  * **Validation Integration**: Added real-time validation feedback in participant input forms with red border indicators
  * **Save Validation**: Enhanced save function to validate all participants before submission
- July 16, 2025: **ENHANCED BID RESULTS DIALOG WITH ADVANCED FEATURES** - Implemented comprehensive bid results management system with all requested enhancements:
  * **Restored RA Data Section**: Added proper Reverse Auction data display with RA Number, Start Amount, and End Amount fields
  * **Added "Add" Button**: Implemented "Add" button before search icon in participant name field for quick competitor creation
  * **Sliding Competitor Form**: Added sliding form to add new competitors with complete details (name, location, representative, contact) stored in database
  * **Autocomplete Search**: Enhanced autocomplete functionality with existing competitors master data integration
  * **Ascending Status Sort**: Implemented proper sorting of bidder status (L1, L2, L3...) in ascending order
  * **Removed Created At Column**: Eliminated "Created At" column from participants table for cleaner interface
  * **Admin-Only Controls**: Maintained admin-only edit/delete functionality for participant management
  * **Master Data Integration**: Full competitors database with comprehensive CRUD operations for future reuse
  * **Improved UX**: Enhanced search, add, and participant management workflow with better visual feedback
- July 16, 2025: **ENHANCED LOGIN RELIABILITY FOR LOCAL DEPLOYMENT** - Fixed intermittent login issues when using local PostgreSQL database:
  * **Database Connection Optimization**: Enhanced database connection pool with auto-SSL detection and improved timeout handling
  * **Retry Logic**: Added retry mechanism for database queries with brief delays to handle temporary connection issues
  * **Timeout Protection**: Implemented 15-second timeout for login requests to prevent hanging connections
  * **Enhanced Error Handling**: Added specific error types for timeout, database connection, and server errors
  * **Frontend Error Messages**: Improved user feedback with detailed error messages for different failure scenarios
  * **Health Check Endpoint**: Added `/api/health` endpoint for database connection monitoring
  * **Connection Pool Improvements**: Increased max connections to 10 and optimized SSL configuration for both local and cloud environments
  * **Graceful Degradation**: Password hashing failures no longer prevent successful login
  * **Better Logging**: Enhanced logging for database connection issues and authentication failures
- July 16, 2025: **ENHANCED FILE PATH HANDLING FOR LOCAL DEPLOYMENT** - Fixed file path storage and handling to support both local and cloud environments:
  * **Path Normalization**: Added utility functions to normalize file paths for database storage (relative paths)
  * **Path Resolution**: Created helper functions to resolve relative paths to absolute paths for file operations
  * **Database Updates**: Updated all file storage methods to save normalized relative paths instead of absolute paths
  * **Download Compatibility**: Fixed file download endpoints to work with both relative and absolute paths
  * **Cross-Platform Support**: File paths now work correctly when database is exported from Replit and imported to local PostgreSQL
  * **Backward Compatibility**: System handles both existing absolute paths and new relative paths seamlessly
  * **Comprehensive Coverage**: Updated all file operations including documents, checklists, responses, and attachments
- July 16, 2025: **FIXED STAR AND INTEREST FUNCTIONALITY** - Resolved tender star and interest actions not working properly:
  * **API Request Format**: Fixed apiRequest function calls to use correct parameter format with method and body
  * **Authentication Headers**: Ensured proper x-user-id header is sent for user authentication
  * **Star Functionality**: Fixed star toggle to properly mark/unmark tenders as starred
  * **Interest Functionality**: Fixed interest toggle to properly mark/unmark tenders as interested
  * **Cache Invalidation**: Enhanced cache invalidation to update UI counts immediately
  * **User Context**: Properly integrated user authentication context for all tender actions
  * **Error Handling**: Improved error handling and user feedback for failed operations
- July 14, 2025: **FIXED PDF GENERATION INDEX OPTION** - Enhanced PDF compilation service to properly handle "Include Index" checkbox:
  * **Index Page Control**: When "Include Index" is unchecked, generated PDF files no longer include an index page
  * **Proper Pagination**: Fixed pagination logic to start from user-specified page number regardless of index page presence
  * **Sequential Numbering**: Document pages now use correct sequential numbering based on startFrom value
  * **Index Page Numbering**: When index is included, it receives the startFrom page number, with documents starting from startFrom+1
  * **Maintained Functionality**: All existing features like stamp application and document merging continue to work properly
- July 14, 2025: **FIXED TENDER ASSIGNMENT FUNCTIONALITY** - Resolved assignment dialog issues and enhanced multi-user assignment capability:
  * **Unified Assignment Dialog**: Replaced broken AssignModal with working TenderAssignDialog across all tender pages
  * **Multi-User Assignment**: Enhanced assignment dialog to support assigning same tender to multiple team members
  * **Persistent Dialog**: Assignment dialog now stays open after successful assignment to allow multiple assignments
  * **Improved UX**: Changed "Save" button to "Assign" and added "Close Dialog" button for better user experience
  * **Authentication Fix**: Resolved authentication errors by replacing apiRequest with fetch API calls with proper headers
  * **Data Display Fix**: Fixed assignment table display by correcting field name mismatches between frontend and backend
  * **Interface Alignment**: Updated Assignment interface to match backend API response structure (assignedBy/assignedTo/remarks/assignedAt)
  * **Purple Theme**: Changed table header background to purple (#7c3aed) with enhanced visibility styling
  * **Removed REMARKS Column**: Eliminated REMARKS column from assignment table for cleaner interface
  * **Removed Hover Effects**: Removed hover effects from table header and rows per user requirements
  * **Swapped Column Order**: Changed column order to ASSIGN TO, ASSIGN BY instead of ASSIGN BY, ASSIGN TO
  * **Themed Delete Dialog**: Replaced basic window.confirm with purple-themed AlertDialog matching website design
  * **Enhanced Debugging**: Added comprehensive logging to track assignment process and authentication issues
  * **Better Error Handling**: Improved error messages and validation for assignment operations
  * **Consistent Experience**: Same assignment functionality now works identically on tender details and tender cards
- July 13, 2025: **FIXED LOGIN REDIRECT ISSUE** - Resolved intermittent login redirect problem where successful login sometimes failed to navigate to dashboard on first attempt:
  * **Root Cause**: Timing race condition between user context update and navigation, plus localStorage key mismatch
  * **LocalStorage Fix**: Now storing user data in both 'user' and 'startender_user' keys for compatibility
  * **Navigation Fix**: Added 100ms delay after context update to ensure proper state synchronization
  * **Logout Fix**: Enhanced logout to clear all relevant localStorage keys (user, startender_user, token)
  * **Consistency**: Both landing page modal and dedicated login page now use identical, robust authentication flow
  * **User Experience**: Login now consistently redirects to Sales Dashboard on first attempt with proper success messaging
- July 13, 2025: **HERO SECTION OPTIMIZATION** - Restructured hero section for full-width layout and improved text positioning:
  * **Full-Width Image**: Removed width constraints to allow hero image to display at full resolution
  * **Top Positioning**: Moved hero image to top of section (directly below header)
  * **Text Below Image**: Relocated main headlines "HAVE A HASSLE FREE BIDDING" and subtitle below the image
  * **Removed Advanced Search**: Eliminated Advanced Search button overlay for cleaner design
  * **Maintained Animations**: Kept animated purple and blue smoke effects in background
  * **Improved Layout**: Better visual hierarchy with image first, then text content
  * **Responsive Design**: Full-width design optimized for all screen sizes
  * **Clean Structure**: Simplified layout with clear separation between image and text elements
  * **Height Optimization**: Set hero image height to 60vh for better proportions
  * **Width Optimization**: Reduced hero image width to 60% for better composition
  * **Animated Cloud Effects**: Added JavaScript-based animated cloudy white gradients on both sides
  * **Cloud Animations**: Created cloud-drift and cloud-drift-reverse CSS animations with 8-second cycles
  * **Layered Effects**: Multiple gradient layers with different opacities and staggered animation delays
  * **Dynamic Background**: Implemented color extraction from hero image with automatic background adaptation
  * **Color Analysis**: JavaScript-based image color analysis using HTML5 Canvas for dominant color detection
  * **Adaptive Theming**: Real-time background gradient generation based on hero image's dominant colors
  * **Color Palette Display**: Visual indicator showing extracted colors in top-right corner
  * **Cross-Origin Support**: Added crossOrigin attribute for proper image processing
  * **Stretched Hero Layout**: Increased hero image height to 80vh for more dramatic presentation
  * **Dynamic Gradient Sides**: White and purple gradients on both sides using extracted image colors
  * **Glass Shadow Effect**: Added glass-like shadow at bottom of image with backdrop-blur
  * **Overlapping Text**: Text content now overlaps image with glassmorphism card design
  * **Enhanced Visual Hierarchy**: Improved text placement with backdrop blur and shadow effects
  * **Removed Color Display**: Eliminated dynamic color palette display widget for cleaner interface
  * **Fixed Header**: Improved header styling with proper SquidJob branding and button layout
  * **Enhanced Navigation**: Added separate Sign In and Get Started buttons with proper styling
  * **Better Backdrop**: Increased header backdrop opacity for better visibility
  * **Non-Floating Header**: Removed sticky positioning and backdrop blur for cleaner design
  * **Logo Only**: Removed "SquidJob" text from header, keeping only the logo
  * **Enhanced Glass Effect**: Upgraded glassmorphism card with 40px blur, gradient background, and frosted matte finish
  * **Advanced Backdrop**: Added custom backdrop filters with saturation and contrast adjustments
  * **White Glow Effect**: Added white shadow glow behind "HAVE A HASSLE FREE BIDDING" text while maintaining original gradient colors
  * **Layered Blur Effects**: Multiple white blur layers with varying opacity (60%, 40%, 30%) and precise scale alignment
  * **Perfect Alignment**: Fixed shadow and text alignment using top-0 left-0 positioning with inline-block display
- July 13, 2025: **PROFESSIONAL UI MOCKUPS** - Replaced application screenshots with custom-designed UI mockups in "How it Works" section:
  * **Modern SVG Illustrations**: Created 6 professional UI mockups using SVG for each bidding step
  * **Consistent Branding**: All mockups use purple theme (#7c3aed) matching website design
  * **Enhanced UX**: Visual mockups more appealing and engaging than actual screenshots
  * **Responsive Design**: SVG illustrations scale perfectly across all devices
  * **Clean Interface**: Professional designs with proper spacing and visual hierarchy
- July 13, 2025: **MODERN LANDING PAGE WITH LOGIN INTEGRATION** - Created beautiful responsive landing page with SquidJob branding and integrated login modal:
  * **Responsive Design**: Mobile-first approach with beautiful gradient backgrounds and smooth animations
  * **SquidJob Branding**: Integrated SquidJob logo with purple/blue gradient text styling
  * **Hero Section**: Compelling headline with search functionality and call-to-action buttons
  * **Features Section**: Six key features with icons and descriptions highlighting platform capabilities
  * **Process Steps**: Six-step bidding process with numbered cards and visual icons
  * **Trust Section**: Company logos section with gradient background
  * **Login Modal**: Integrated popup login dialog with form validation and loading states
  * **Authentication Flow**: Seamless login process that redirects to Sales Dashboard on success
  * **User Experience**: Toast notifications for login feedback with personalized welcome messages
  * **Modern UI**: Used Tailwind CSS with shadcn/ui components for consistent styling
  * **SEO Optimized**: Clean structure with proper headings and semantic HTML
  * **Performance**: Optimized images and efficient component structure
  * **Navigation**: Smooth scrolling navigation with sticky header
  * **Routing**: Integrated with wouter routing system, landing page at root path "/"
  * **Redesigned Login Page**: Complete redesign of individual login page matching landing page theme with same header/footer, "Back to Home" navigation link, two-column layout with features showcase on left and login form on right, consistent purple/blue branding throughout
  * **Security Enhancement**: Removed all hardcoded credentials from both login methods for enhanced security
  * **Unified Authentication**: Both login modal and individual login page now provide consistent authentication flow with proper token storage and immediate redirect to Sales Dashboard
- July 12, 2025: **COMPREHENSIVE SECURITY HARDENING** - Completed all vulnerability fixes to achieve enterprise-grade security:
  * **Authentication Security**: Replaced insecure header-based authentication with JWT token system (24-hour expiry)
  * **Password Security**: Implemented bcrypt password hashing (salt rounds: 12) with automatic migration from plaintext
  * **Removed Security Risks**: Eliminated hardcoded admin credentials from frontend code
  * **API Security**: Added comprehensive input validation and sanitization using express-validator on all endpoints
  * **File Upload Security**: Enhanced file type validation, size limits (50MB), filename sanitization, and malicious file filtering
  * **Rate Limiting**: Configured secure rate limiting (100 requests/15min general, 5 login attempts/15min) with proper proxy trust
  * **Security Headers**: Implemented Helmet.js with CSP, HSTS, and anti-clickjacking protection
  * **Authorization**: Added role-based access control with admin-only endpoint protection and insecure direct object reference prevention
  * **Password Management**: Created secure password change endpoint with validation
  * **Error Handling**: Improved error responses to prevent information disclosure
  * **Session Management**: Implemented proper JWT-based session handling with logout functionality
  * **Query Security**: Added parameter validation to prevent SQL injection attacks
  * **User Management**: Enhanced user creation/update with comprehensive validation and authorization checks
  * **File Security**: Implemented secure filename handling, path traversal prevention, and comprehensive file type validation across all upload endpoints
- July 12, 2025: Updated Approval page table theme to match website's purple color scheme. Changed table header background from blue (`bg-[#0076a8]`) to purple (`bg-purple-600`), updated all buttons and interactive elements to use purple theme colors, and applied consistent hover effects. Moved Task and Approval menus from main sidebar to become sub-menu items under MIS main menu for better organization. Updated database menu structure to reflect new hierarchy with MIS showing 5 sub-items: Finance MIS, Sales MIS, Login MIS, Task, and Approvals.
- July 12, 2025: Connected Task page to sidebar menu navigation. Fixed Task page routing from lazy loading to direct component import for better performance. Task page now accessible via sidebar "Task" menu item at `/tasks` route with proper task module permission checking. Displays comprehensive task allocation table with live data matching user's table structure requirements including columns for Tender ID, Tender Name, Client Name, Location, Due Date, Task Work, Assignor/Assignee Names, Created Date & Time, Deadline, Status, and Action buttons with purple theme consistency. Enhanced Tender ID column to show only last 7 digits with clickable links to tender details page for easy navigation.
- July 12, 2025: Fixed dynamic tab counts functionality on All Tenders page. Updated star and interested actions to be user-specific with instant tab count updates. Fixed Live tab to show tenders with valid days left (≥0 days) and Archive tab to show expired tenders (<0 days). Enhanced backend user ID handling for proper authentication in tender counts and filtering. Fixed Tender Checklist page back button to navigate to Tender Details page instead of general tenders page. Fixed Task Allocation dialog runtime error by correcting API request usage - replaced incorrect apiRequest usage in query operations with proper fetch calls for data retrieval. Updated all purple colors on Tender Details page to use consistent website theme colors. Applied btn-purple class to "View Response" button, "TENDER FEATURES" header, and download buttons to match the website's purple theme (#7c3aed). Updated "View Response" button to use purple background with yellow icon when responses exist, maintaining gray appearance for "Prepare Response" when no responses exist. Enhanced PDF compression system with visual indicators and improved user experience. Fixed download buttons to show original file sizes for "Download Original File" and color-coded compressed file buttons (Red for extreme, Orange for recommended, Yellow for light compression) with file sizes and compression percentages. Updated light (80% quality) and recommended (55% quality) compression to use Ghostscript for better compression ratios. Enhanced download popup to display accurate file information and compression details.
- July 12, 2025: Fixed PDF compression functionality to provide accurate compression results instead of hardcoded values. Created enhanced compression service with aggressive compression techniques for extreme mode, including proper image optimization, metadata removal, and content scaling. Fixed frontend display to show actual compression percentages and file sizes. Extreme compression now provides significant size reduction through multiple compression techniques.
- July 12, 2025: Updated "Days Left" color coding across all tender pages to show green text for more than 3 days remaining, orange text for less than 3 days remaining, and red text for expired tenders (negative days). Applied consistent styling with font-medium for orange and font-bold for red text to improve visual hierarchy and urgency indication.
- July 10, 2025: Removed checklist field from settings menu as requested. Updated sidebar navigation and menu management structures to exclude checklist settings submenu. Cleaned up settings page by removing ChecklistSettings component and related tab handling. Maintained existing checklist functionality accessible through document management section. Fixed Dashboard section visibility for non-admin users by enhancing permission checking logic to show Dashboard section when users have salesDashboard or financeDashboard permissions. Resolved checklist page access issues by properly mapping document management permissions and adding fallback checks for standalone checklist permissions. Enhanced permission system to handle nested permission structures (documentManagement.folder, documentManagement.documentBriefCase, settings.checklist).
- July 9, 2025: Fixed authentication headers issue in tender checklist creation. Updated frontend to properly send x-user-id header for fetch requests in tender checklist uploads and responses, ensuring new documents are correctly attributed to the current logged-in user. Enhanced cache invalidation to update Activity Log and Tender Documents sections immediately when new checklist documents are created. Fixed document categorization logic to properly identify Financial, Technical, and Commercial response types as "Generated Tender Checklist Documents" instead of "Prepare Response".
- July 9, 2025: Enhanced RA (Reverse Auction) functionality with conditional display and data persistence. The RA section now only appears within Tender Details when actual RA data exists, maintaining the red outline theme. Removed redundant "Bid No." field from RA popup form since tender reference number is auto-populated. Added functionality to display previously submitted RA data when popup is reopened for editing. Enhanced RA popup with separate time fields for start/end times, made start amount, end amount, and document upload optional. Added document download functionality for existing documents with replace option. Updated RA display to show actual user names instead of "User ID", removed Bid No. from display, enforced 24-hour time format without seconds, and prevented duplicate table entries when updating RA data. Implemented latest-only RA display to show only the most recent entry and moved Created by/Created on details to footer with small, light styling. Removed RA title for cleaner interface. Fixed critical authentication issue where RA updates were showing wrong user names by ensuring proper x-user-id header is sent in RA creation/update requests. Fixed document download functionality by adding proper download endpoint `/api/ra/:id/download` that serves files correctly. Updated My Tenders page with new tab structure (Fresh, Live, Bid to RA, Expired, Interested) and aligned UI/UX to match All Tenders page design exactly. Enhanced backend to show both assigned tenders and user-interested tenders with proper filtering for each tab status. Implemented exact tender card layout matching All Tenders page with horizontal information display, proper document links, and consistent action buttons.
- July 8, 2025: Reorganized Tender Task menu structure by removing non-functional items (My Tender, Assign to Team, Submitted Tender, Tender Checklist) and adding functional pages (My Tender, In-Process, Assigned To Team, Submitted Tender, Dropped Tender, Rejected) with proper routing paths. This improvement ensures all menu items under Tender Task are fully functional and accessible.
- July 8, 2025: Fixed non-functional Department, Designation, Role, and User Management pages by adding missing routes to App.tsx and updating Settings component to handle route-based tab selection. Enhanced date/time field display with proper DD/MM/YYYY HH:MM format across all settings pages. Made Checklist Settings page fully functional with complete CRUD operations including add, edit, delete functionality integrated with existing database API endpoints.
- July 8, 2025: Simplified calendar UI/UX on Sales Dashboard with cleaner design, removed complex tooltips, streamlined event display, and improved layout proportions (2/3 calendar, 1/3 events). Removed unnecessary "All Time" text from dashboard metrics and cleaned up redundant UI elements.
- July 8, 2025: Successfully removed "Bid Management" menu section and all 3 submenus from sidebar navigation. Updated database menu structure and Settings menu order to maintain proper sequential ordering.
- July 8, 2025: Fixed calendar date visibility issues and replaced mock notifications with real tender/bid data. Enhanced calendar styling with better contrast and readability. Notification widget now shows actual upcoming deadlines and recent activities from database with dynamic priority-based color coding.
- July 8, 2025: Restructured Sales Dashboard layout with calendar widget in separate row and full-height Notification & Reminders widget on right side. Enhanced notification system with color-coded priority levels, icons, and hover effects for better user experience.
- July 8, 2025: Updated Sales Dashboard layout to match Finance Dashboard's clean UI/UX design. Implemented gradient background, centered logo header, white card-based layout with consistent spacing and shadows, and reorganized information boxes for better visual hierarchy and responsiveness.
- July 8, 2025: Removed OEM Management main menu section and its 3 submenus (Add Company, Manage Company, Link Dealer) from dynamic menu structure. Updated Settings menu order to 8 to maintain proper sequential ordering.
- July 8, 2025: Successfully restored missing "Bid Management" section to database menu structure with 3 submenus: Company Management, Bid Participation, and Document Compilation & Export. Reordered sections for optimal navigation flow.
- July 8, 2025: Fixed critical "Assign By: System" issue in My Tender page by correcting data structure transformation to properly display assignedBy user names. Updated backend assignment logic to use authenticated user ID instead of hardcoded fallback. Corrected database records to show proper assignment relationships (all assignments now show Poonam Amale as assigner instead of incorrect Amit Pathariya references).
- July 8, 2025: Added comprehensive tooltip functionality across document management sections. Implemented tooltips for Edit, Delete, and Add Document icons in checklist settings page, Edit, Download, Delete action buttons in document brief case page, and Edit, Delete, Download action buttons in folder management table. Enhanced user experience with hover tooltips showing clear action descriptions. Added tooltip for "Create New Folder" button in file upload dialog.
- July 4, 2025: Implemented SMTP-based email notification system for tender assignments. When a tender is assigned to a team member, the system automatically sends a professional email notification with tender details, assignment information, and formatted dates. Added email test functionality in Settings page with SMTP configuration support for Gmail, Outlook, Yahoo, and custom SMTP servers.
- July 3, 2025: Standardized tender filter sections across all tender pages with comprehensive user integration, Indian states with manual search capability, and consistent field structure. Enhanced TenderFilter component with registered user data for Assign To/Assign By dropdowns, removed reference number field from non-All Tender pages, added missing fields (Department Name, Closing dates, Owner/Right), and implemented page-specific filter behavior for submitted vs other tender pages.
- July 3, 2025: Fixed tender detail page button logic to correctly show "Prepare Response" when no responses exist and "View Response" when responses are already created. Fixed incorrect API endpoint query that was preventing proper response detection.
- July 2, 2025: Implemented intelligent PDF compression with size-based targets - files >10MB compress to 5-6MB, 5-10MB files compress to 1-2MB, 1-5MB files compress to KB range. Added iterative compression algorithm and aggressive optimization techniques for optimal file size reduction
- July 2, 2025: Enhanced All Tenders page with PDF compression functionality and consistent icon implementation across all tender listing pages
- June 28, 2025. Enhanced Generated Tender Checklist Documents table with sortable columns and moved to top of page for better user experience
- June 26, 2025. Restored complete "Generate Response" functionality for tender checklist with authentic file download system
- June 26, 2025. Implemented comprehensive Prepare Checklist modal matching user specifications with document selection and ZIP file generation
- June 26, 2025. Enhanced Tender Checklist module with major UI/UX improvements including autocomplete with dropdown auto-hide, PDF thumbnail previews, enhanced document management, and streamlined interface
- June 26, 2025. Removed duplicate "Prepare Checklist" sections and consolidated functionality into main checklist area
- June 26, 2025. Added backend API endpoint for generating tender-specific checklist response downloads with authentic document handling
- June 24, 2025. Completed Kick Off Call functionality with date/time picker, database integration, and table display matching user requirements
- June 24, 2025. Finalized Task Allocation dialog UI by removing highlighted description text and perfecting layout to match user specifications
- June 24, 2025. Completed Task Allocation functionality with combined date/time picker, proper database integration, and real-time data table display
- June 24, 2025. Modified Request to Finance form layout with combined deadline/reminder time field and comprehensive data table below form
- June 24, 2025. Fixed task_allocations database table structure and resolved authentication issues for task creation
- June 24, 2025. Updated both Task Allocation and Request to Finance dialogs to match specified UI requirements from attached images
- June 24, 2025. Implemented proper backend logic for both features with real database storage and immediate table updates
- June 19, 2025. Fixed Today's Activity to show reminders for tenders assigned to current user, not reminders created by current user
- June 19, 2025. Updated database query to join with tender assignments to show proper reminder visibility
- June 19, 2025. Fixed date range comparison logic in Today's Activity API endpoint
- June 19, 2025. Verified Today's Activity now correctly shows reminders with proper user attribution based on tender assignments
- June 19, 2025. Restored hierarchical Dashboard menu structure with Sales Dashboard and Finance Dashboard as submenu items
- June 19, 2025. Updated routing to redirect root path "/" to Sales Dashboard instead of main dashboard
- June 19, 2025. Completed Today's Activity implementation across all dashboards with real reminder data integration
- June 19, 2025. Fixed Sales Dashboard to use TodaysActivityWidget component instead of hardcoded dummy data
- June 19, 2025. Replaced dummy data in Today's Activity dashboard with real reminder data from database
- June 19, 2025. Created TodaysActivityWidget component showing real reminder activities for current day  
- June 19, 2025. Added getTodaysReminderActivities API endpoint and database method
- June 19, 2025. Enabled Set Reminder functionality on tender details page with consistent UI across all pages
- June 15, 2025. Completed customizable dashboard widget layout system with full responsive design and real data integration
- June 15, 2025. Updated to new SquidJob logo with larger size (h-16) across all dashboard pages while maintaining proper proportions
- June 15, 2025. Implemented purple button theme with beautiful icons for seamless design experience across all pages
- June 15, 2025. Enhanced UI theming with consistent button styling and improved table contrast
- June 14, 2025. Initial setup

## User Preferences

Preferred communication style: Simple, everyday language.