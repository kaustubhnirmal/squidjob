#!/usr/bin/env node

/**
 * Deployment Test Script
 * This script verifies that the deployment fixes work correctly
 */

import { existsSync } from 'fs';
import { resolve } from 'path';
import { execSync } from 'child_process';

console.log('🔍 Testing Deployment Fixes...\n');

// Test 1: Check required files exist
console.log('1. Checking required files...');
const requiredFiles = [
  'server.js',
  'server/index.ts',
  'database_setup_postgresql13.sql',
  'start-production.js',
  'CPANEL_DEPLOYMENT_SOLUTION_GUIDE.md'
];

let filesOk = true;
requiredFiles.forEach(file => {
  if (existsSync(file)) {
    console.log(`   ✅ ${file} - Found`);
  } else {
    console.log(`   ❌ ${file} - Missing`);
    filesOk = false;
  }
});

// Test 2: Check Node.js version compatibility
console.log('\n2. Checking Node.js version...');
const nodeVersion = process.version;
const majorVersion = parseInt(nodeVersion.substring(1).split('.')[0]);
if (majorVersion >= 18) {
  console.log(`   ✅ Node.js ${nodeVersion} - Compatible (ES modules supported)`);
} else {
  console.log(`   ⚠️  Node.js ${nodeVersion} - May have issues (recommend 18+)`);
}

// Test 3: Check package dependencies
console.log('\n3. Checking critical dependencies...');
try {
  const packageJson = JSON.parse(require('fs').readFileSync('package.json', 'utf8'));
  const criticalDeps = ['tsx', 'express', 'drizzle-orm', 'pg'];
  
  criticalDeps.forEach(dep => {
    if (packageJson.dependencies[dep] || packageJson.devDependencies?.[dep]) {
      console.log(`   ✅ ${dep} - Listed in package.json`);
    } else {
      console.log(`   ❌ ${dep} - Missing from package.json`);
    }
  });
} catch (error) {
  console.log(`   ❌ Failed to read package.json: ${error.message}`);
}

// Test 4: Check if tsx can be loaded
console.log('\n4. Testing TypeScript loader...');
try {
  execSync('npx tsx --version', { stdio: 'pipe' });
  console.log('   ✅ tsx - Available and working');
} catch (error) {
  console.log('   ⚠️  tsx - Not available, may need: npm install tsx');
}

// Test 5: Validate server.js syntax
console.log('\n5. Validating server.js syntax...');
try {
  require('fs').readFileSync('server.js', 'utf8');
  console.log('   ✅ server.js - Syntax appears valid');
} catch (error) {
  console.log(`   ❌ server.js - Syntax error: ${error.message}`);
}

// Test 6: Check database setup file
console.log('\n6. Validating database setup...');
try {
  const sqlContent = require('fs').readFileSync('database_setup_postgresql13.sql', 'utf8');
  if (sqlContent.includes('CREATE TABLE users') && sqlContent.includes('INSERT INTO users')) {
    console.log('   ✅ database_setup_postgresql13.sql - Contains required tables and data');
  } else {
    console.log('   ⚠️  database_setup_postgresql13.sql - May be incomplete');
  }
} catch (error) {
  console.log(`   ❌ Database setup file error: ${error.message}`);
}

// Summary
console.log('\n📋 Deployment Readiness Summary:');
if (filesOk && majorVersion >= 18) {
  console.log('   ✅ Ready for deployment to cPanel hosting');
  console.log('   📖 Follow instructions in CPANEL_DEPLOYMENT_SOLUTION_GUIDE.md');
} else {
  console.log('   ⚠️  Some issues detected - review errors above');
}

console.log('\n🚀 Deployment Steps:');
console.log('   1. Upload all files to cPanel public_html directory');
console.log('   2. Run: npm install');
console.log('   3. Setup database using database_setup_postgresql13.sql');
console.log('   4. Configure .env file with database credentials');
console.log('   5. Start with: node server.js');

console.log('\n🔧 If startup fails, try alternatives:');
console.log('   - node start-production.js');
console.log('   - npx tsx server/index.ts');
console.log('   - Check CPANEL_DEPLOYMENT_SOLUTION_GUIDE.md for troubleshooting');