# Responsive Fix Installation - Step by Step

## BEFORE YOU START
**IMPORTANT**: Create a backup of your original files before replacing them.

## Installation Steps

### Step 1: Stop Your Server
```bash
# If using PM2:
pm2 stop all

# If using direct node:
killall node

# Or press Ctrl+C if running in terminal
```

### Step 2: Backup Original Files (IMPORTANT)
```bash
# Create backup directory
mkdir -p backups

# Backup original files
cp client/src/pages/tenders.tsx backups/tenders.tsx.backup
cp client/src/pages/my-tenders.tsx backups/my-tenders.tsx.backup
```

### Step 3: Replace Files
```bash
# Replace with responsive versions
cp client/src/pages/tenders.tsx client/src/pages/tenders.tsx
cp client/src/pages/my-tenders.tsx client/src/pages/my-tenders.tsx
```

### Step 4: Rebuild Application
```bash
# Install dependencies (if needed)
npm install

# Build the application
npm run build
```

### Step 5: Start Server
```bash
# Using PM2:
pm2 start start-production-vps.cjs --name "tender247"

# Or using npm:
npm start
```

### Step 6: Test
- Open your website
- Check "All Tenders" page on mobile/desktop
- Check "My Tenders" page on mobile/desktop
- Verify all functionality works

## If You Get 503 Error

### Quick Fix:
```bash
# Check server status
pm2 status

# Check logs for errors
pm2 logs

# If server crashed, restart:
pm2 restart all
```

### If Still Not Working:
1. Restore backup files:
   ```bash
   cp backups/tenders.tsx.backup client/src/pages/tenders.tsx
   cp backups/my-tenders.tsx.backup client/src/pages/my-tenders.tsx
   ```

2. Rebuild and restart:
   ```bash
   npm run build
   pm2 restart all
   ```

## What These Files Do
- Make tender pages mobile-friendly
- Responsive layouts for phones and tablets
- Better button and text sizing
- Improved navigation on small screens

## No Database Changes
These are frontend-only changes. Your database remains unchanged.

## Support
If you continue having issues, check the TROUBLESHOOTING_503_ERROR.md file for detailed debugging steps.