# 503 Service Unavailable Error - Troubleshooting Guide

## Problem
After replacing the responsive files, the website shows "503 Service Unavailable" error.

## Cause
The production server cannot compile the new TypeScript/JSX files, causing the application to crash.

## IMMEDIATE SOLUTION

### Step 1: Check Server Logs
```bash
# Check if your server is running
pm2 status
# OR
ps aux | grep node

# Check server logs for errors
pm2 logs
# OR check your application logs
```

### Step 2: Restart the Build Process
```bash
# Navigate to your project directory
cd /var/www/html/your-project-folder

# Stop the current server
pm2 stop all
# OR
killall node

# Rebuild the application
npm run build

# Start the server again
npm start
# OR
pm2 start start-production-vps.cjs --name "tender247"
```

### Step 3: If Build Fails
If you see TypeScript/compilation errors:

```bash
# Install dependencies again
npm install

# Try building again
npm run build

# If still failing, check for syntax errors in the new files
```

## SAFE ROLLBACK (If above doesn't work)

### Restore Original Files
1. Stop the server
2. Replace the responsive files with your original backup files
3. Restart the server
4. Confirm the site works again

## ALTERNATIVE: Pre-built Solution

I'll create a pre-built version of the files that should work without compilation issues.

## Server Requirements Check

Make sure your server has:
- Node.js 18+ installed
- npm/yarn package manager
- TypeScript compiler (should be in devDependencies)
- All project dependencies installed

## Common Error Patterns

1. **Missing Dependencies**: Run `npm install`
2. **TypeScript Errors**: Check for syntax issues in new files
3. **Memory Issues**: Server may need more RAM to compile
4. **File Permissions**: Ensure files have correct read permissions

## Next Steps

If the issue persists:
1. Check server logs for specific error messages
2. Try the pre-built solution I'll provide
3. Verify all dependencies are properly installed
4. Ensure the server has sufficient resources