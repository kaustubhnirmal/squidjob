#!/bin/bash
# Quick VPS deployment script

echo "🚀 Starting Tender247 deployment..."

# Install dependencies
npm install

# Setup PostgreSQL
chmod +x deployment/almalinux-setup.sh
./deployment/almalinux-setup.sh

# Setup database schema
npm run db:push

# Build application
npm run build

# Install PM2 if not installed
if ! command -v pm2 &> /dev/null; then
    sudo npm install -g pm2
fi

# Start application
pm2 start npm --name "tender247" -- run start

echo "✅ Deployment completed!"
echo "Application running on http://localhost:5000"