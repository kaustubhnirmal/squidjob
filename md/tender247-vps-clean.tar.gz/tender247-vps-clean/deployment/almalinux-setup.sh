#!/bin/bash
# PostgreSQL 13 setup script for AlmaLinux 9

echo "🐘 Setting up PostgreSQL 13 for AlmaLinux 9..."

# Install PostgreSQL 13
sudo dnf install -y postgresql13-server postgresql13

# Initialize database
sudo /usr/pgsql-13/bin/postgresql-13-setup initdb

# Start and enable PostgreSQL
sudo systemctl enable postgresql-13
sudo systemctl start postgresql-13

# Create database and user
sudo -u postgres psql << EOF
CREATE USER tender247_user WITH PASSWORD 'tender247_pass';
CREATE DATABASE tender247_db OWNER tender247_user;
GRANT ALL PRIVILEGES ON DATABASE tender247_db TO tender247_user;
\q
EOF

# Create .env file
cat > .env << EOF
DATABASE_URL=postgresql://tender247_user:tender247_pass@localhost:5432/tender247_db
NODE_ENV=production
PORT=5000
EOF

echo "✅ PostgreSQL 13 setup completed!"
echo "Database: tender247_db"
echo "User: tender247_user"
echo "Password: tender247_pass"