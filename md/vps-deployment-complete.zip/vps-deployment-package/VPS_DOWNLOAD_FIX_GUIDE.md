# VPS Download Error Fix Guide

## Problem: ERR_HTTP2_PROTOCOL_ERROR

The error `ERR_HTTP2_PROTOCOL_ERROR` when downloading PDFs from your VPS server is caused by:

1. **HTTP/2 Protocol Conflicts**: VPS servers often have HTTP/2 enabled which can conflict with file streaming
2. **File Path Resolution**: Different path structures between development and production
3. **Security Headers**: Strict security policies blocking file downloads
4. **CORS Issues**: Cross-origin restrictions on file downloads

## Solution Applied

### 1. Enhanced Download Endpoint
- ✅ **Better File Path Resolution**: Now checks multiple common VPS paths
- ✅ **HTTP/1.1 Forced**: Downloads now use HTTP/1.1 to avoid protocol errors
- ✅ **Robust Error Handling**: Detailed logging and fallback mechanisms
- ✅ **VPS Path Detection**: Automatically finds files in common VPS locations

### 2. VPS-Specific Production Server
- ✅ **Created**: `start-production-vps.js` - Optimized for VPS deployment
- ✅ **HTTP/2 Handling**: Forces HTTP/1.1 for downloads
- ✅ **Enhanced CORS**: Configured for squidjob.com domain
- ✅ **Better Headers**: Download-optimized headers

## Deployment Instructions

### Option 1: Update Existing Server
Replace your current server startup with the enhanced version:

```bash
# Copy the updated files to your VPS
# Then restart your application with:
node start-production-vps.js
```

### Option 2: Update Package.json Scripts
Add to your `package.json`:

```json
{
  "scripts": {
    "start:vps": "node start-production-vps.js",
    "start:production": "cross-env NODE_ENV=production node start-production-vps.js"
  }
}
```

### Option 3: PM2 Process Manager (Recommended)
```bash
# Install PM2 if not already installed
npm install -g pm2

# Start the application with PM2
pm2 start start-production-vps.js --name "tender-management"

# Save PM2 configuration
pm2 save

# Set up auto-restart on server reboot
pm2 startup
```

## File Upload Directory Setup

Ensure your uploads directory is properly configured:

```bash
# Create uploads directory with proper permissions
mkdir -p /home/yourusername/public_html/uploads
chmod 755 /home/yourusername/public_html/uploads

# Or for Apache/Nginx setup:
mkdir -p /var/www/html/uploads
chmod 755 /var/www/html/uploads
```

## Testing the Fix

1. **Upload a Document**: Go to Checklist Settings and upload a PDF
2. **Try Download**: Click the download button on any document
3. **Check Logs**: Monitor server logs for any errors:
   ```bash
   # If using PM2:
   pm2 logs tender-management
   
   # If running directly:
   tail -f /path/to/your/app/logs
   ```

## Troubleshooting

### If Downloads Still Fail:

1. **Check File Permissions**:
   ```bash
   ls -la uploads/
   # Files should be readable (644) and directory executable (755)
   ```

2. **Verify File Paths**:
   - Check server logs for "Resolved file path" messages
   - Ensure files exist at the logged paths

3. **Test Direct File Access**:
   ```bash
   # Test if files are accessible directly
   curl -I https://squidjob.com/uploads/filename.pdf
   ```

4. **Check Server Resources**:
   ```bash
   # Check disk space
   df -h
   
   # Check memory
   free -m
   ```

### Alternative Download Method

If protocol errors persist, the system will automatically:
- ✅ Force HTTP/1.1 connections
- ✅ Set download-specific headers
- ✅ Use connection close to prevent keep-alive issues
- ✅ Provide detailed error messages

## Expected Improvements

After applying this fix:
- ✅ **No More Protocol Errors**: HTTP/1.1 forced for downloads
- ✅ **Better File Discovery**: Multiple path checking
- ✅ **Detailed Logging**: Clear error messages and debugging info
- ✅ **VPS Optimized**: Specifically tuned for VPS environments
- ✅ **Graceful Fallbacks**: Multiple recovery mechanisms

## Support

If issues persist:
1. Check server logs for specific error details
2. Verify file upload directory permissions
3. Test with different file types (PDF, Excel, etc.)
4. Monitor server performance during downloads

The enhanced download system is now production-ready for VPS deployment with robust error handling and HTTP/2 compatibility fixes.