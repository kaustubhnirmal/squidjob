# VPS Deployment Instructions - Download Fix

## Quick Deployment Steps

### 1. Download Files to Your VPS

Upload these files to your VPS server:
- `start-production-vps.js` (Enhanced server with HTTP/2 fix)
- `deploy-vps-fix.sh` (Automated deployment script)
- `VPS_DOWNLOAD_FIX_GUIDE.md` (Troubleshooting guide)
- Updated `server/routes.ts` (Enhanced download endpoint)

### 2. Make Deployment Script Executable

```bash
chmod +x deploy-vps-fix.sh
```

### 3. Run Deployment

```bash
# Basic deployment to current directory
./deploy-vps-fix.sh

# Or specify custom directory
./deploy-vps-fix.sh /path/to/your/app
```

## Manual Deployment (Alternative)

If you prefer manual deployment:

### Step 1: Backup Current Files
```bash
cp server/routes.ts server/routes.ts.backup
cp start-production.js start-production.backup 2>/dev/null || true
```

### Step 2: Stop Current Application
```bash
# If using PM2
pm2 stop tender-management
pm2 delete tender-management

# Or kill process on port 5000
lsof -ti:5000 | xargs kill -9 2>/dev/null || true
```

### Step 3: Deploy New Files
```bash
# Copy the enhanced server file
cp start-production-vps.js ./

# Copy updated routes (download the latest from Replit)
cp server/routes.ts ./server/

# Set permissions
chmod +x start-production-vps.js
```

### Step 4: Create Upload Directories
```bash
mkdir -p uploads
chmod 755 uploads

# For web server setups
mkdir -p /var/www/html/uploads 2>/dev/null || true
chmod 755 /var/www/html/uploads 2>/dev/null || true
```

### Step 5: Start Application
```bash
# Method 1: Using PM2 (Recommended)
pm2 start start-production-vps.js --name "tender-management"
pm2 save

# Method 2: Direct execution
NODE_ENV=production node start-production-vps.js

# Method 3: Background execution
nohup NODE_ENV=production node start-production-vps.js > app.log 2>&1 &
```

## Verification

### Check Application Status
```bash
# If using PM2
pm2 status
pm2 logs tender-management

# Check port
netstat -tulpn | grep :5000

# Test health endpoint
curl http://localhost:5000/health
```

### Test Download Functionality
1. Open your application: `https://squidjob.com`
2. Go to Settings → Checklist Settings
3. Upload a PDF document
4. Try downloading the document
5. Verify no HTTP/2 protocol errors occur

## What's Fixed

### Before Fix:
- ❌ ERR_HTTP2_PROTOCOL_ERROR on downloads
- ❌ File path resolution issues
- ❌ CORS problems with downloads
- ❌ HTTP/2 protocol conflicts

### After Fix:
- ✅ HTTP/1.1 forced for downloads
- ✅ Multiple VPS path checking
- ✅ Enhanced error handling
- ✅ Download-optimized headers
- ✅ Better CORS configuration
- ✅ Detailed logging for debugging

## File Locations Checked

The system now automatically searches for files in:
1. `./uploads/` (application directory)
2. `/home/username/public_html/uploads/`
3. `/var/www/html/uploads/`

## Environment Variables

Set these for optimal performance:
```bash
export NODE_ENV=production
export PORT=5000
export HTTPS_ENABLED=true  # If using HTTPS
```

## Troubleshooting

### If Downloads Still Fail:
1. Check server logs: `pm2 logs tender-management`
2. Verify file permissions: `ls -la uploads/`
3. Test direct file access: `curl -I https://squidjob.com/uploads/filename.pdf`
4. Check disk space: `df -h`

### Common Issues:
- **Permission Denied**: `chmod 755 uploads/` and `chmod 644 uploads/*`
- **File Not Found**: Check if files exist in expected locations
- **Port Conflicts**: Ensure port 5000 is available

## Rollback Instructions

If you need to rollback:
```bash
# Stop new version
pm2 stop tender-management

# Restore backup files
cp server/routes.ts.backup server/routes.ts
cp start-production.backup start-production.js

# Start old version
pm2 start start-production.js --name "tender-management"
```

## Support

The deployment includes:
- Enhanced error logging
- Automatic path detection
- HTTP/2 compatibility fixes
- VPS-optimized configuration

Your download functionality should now work perfectly without any protocol errors.