#!/usr/bin/env node

/**
 * VPS Production Startup Script for Tender Management System
 * Handles HTTP/2 protocol issues and file download compatibility
 * Optimized for VPS deployment with Node.js module compatibility
 */

// Force CommonJS module resolution for VPS compatibility
process.env.NODE_OPTIONS = '--loader ts-node/esm';

const express = require('express');
const path = require('path');
const fs = require('fs');
const cors = require('cors');
const helmet = require('helmet');

// Check if we're in production
const isProduction = process.env.NODE_ENV === 'production';
const port = process.env.PORT || 5000;

console.log('Starting Tender Management System - VPS Production Mode');
console.log(`Port: ${port}`);
console.log(`Environment: ${process.env.NODE_ENV || 'development'}`);
console.log(`Node.js version: ${process.version}`);
console.log(`Working directory: ${process.cwd()}`);

// Import the main server setup with multiple fallback methods
let setupServer;

async function loadServerModule() {
  try {
    // Method 1: Try compiled JavaScript
    const compiledPath = path.join(__dirname, 'dist', 'server', 'index.js');
    if (fs.existsSync(compiledPath)) {
      console.log('Loading compiled server from dist...');
      const serverModule = require(compiledPath);
      return serverModule.setupServer || serverModule.default?.setupServer || serverModule;
    }

    // Method 2: Try direct server.js if it exists
    const serverJsPath = path.join(__dirname, 'server.js');
    if (fs.existsSync(serverJsPath)) {
      console.log('Loading server.js...');
      const serverModule = require(serverJsPath);
      return serverModule.setupServer || serverModule.default?.setupServer || serverModule;
    }

    // Method 3: Try tsx with TypeScript
    try {
      console.log('Loading TypeScript server with tsx...');
      const { register } = require('tsx/cjs');
      register();
      const serverModule = require('./server/index.ts');
      return serverModule.setupServer || serverModule.default?.setupServer || serverModule;
    } catch (tsxError) {
      console.log('tsx not available, trying ts-node...');
    }

    // Method 4: Try ts-node
    try {
      console.log('Loading TypeScript server with ts-node...');
      require('ts-node/register');
      const serverModule = require('./server/index.ts');
      return serverModule.setupServer || serverModule.default?.setupServer || serverModule;
    } catch (tsNodeError) {
      console.log('ts-node not available, using fallback...');
    }

    // Method 5: Fallback - create a minimal server setup
    console.log('Using fallback server setup...');
    return createFallbackServer;

  } catch (error) {
    console.error('Error loading server module:', error.message);
    throw error;
  }
}

// Fallback server creation function
function createFallbackServer(app) {
  console.log('Setting up fallback server configuration...');
  
  // Add basic middleware
  app.use(express.json({ limit: '50mb' }));
  app.use(express.urlencoded({ extended: true, limit: '50mb' }));
  
  // Basic routes
  app.get('/api/health', (req, res) => {
    res.json({ 
      status: 'ok', 
      message: 'Fallback server running',
      timestamp: new Date().toISOString() 
    });
  });
  
  // Serve static files
  const staticDirs = [
    path.join(__dirname, 'dist'),
    path.join(__dirname, 'client', 'dist'),
    path.join(__dirname, 'public')
  ];
  
  for (const dir of staticDirs) {
    if (fs.existsSync(dir)) {
      app.use(express.static(dir));
      console.log(`Serving static files from: ${dir}`);
      break;
    }
  }
  
  return Promise.resolve();
}

async function startVPSServer() {
  try {
    const app = express();

    // VPS-specific middleware for download compatibility
    app.use((req, res, next) => {
      // Force HTTP/1.1 for file downloads to avoid HTTP/2 protocol errors
      if (req.url.includes('/download')) {
        console.log(`📥 Download request: ${req.url}`);
        res.setHeader('Connection', 'close');
        res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
        res.setHeader('Pragma', 'no-cache');
        res.setHeader('Expires', '0');
      }
      next();
    });

    // Enhanced CORS for VPS deployment
    app.use(cors({
      origin: [
        'https://squidjob.com',
        'http://squidjob.com',
        'https://www.squidjob.com',
        'http://www.squidjob.com',
        `http://localhost:${port}`,
        `https://localhost:${port}`,
        // Add your domain patterns here
        /\.squidjob\.com$/
      ],
      credentials: true,
      methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS', 'PATCH'],
      allowedHeaders: [
        'Origin', 
        'X-Requested-With', 
        'Content-Type', 
        'Accept', 
        'Authorization',
        'x-user-id',
        'Cache-Control'
      ],
      exposedHeaders: [
        'Content-Disposition',
        'Content-Length',
        'Content-Type'
      ]
    }));

    // Security headers optimized for file downloads
    app.use(helmet({
      crossOriginEmbedderPolicy: false,
      contentSecurityPolicy: {
        directives: {
          defaultSrc: ["'self'"],
          styleSrc: ["'self'", "'unsafe-inline'"],
          scriptSrc: ["'self'", "'unsafe-inline'", "'unsafe-eval'"],
          imgSrc: ["'self'", "data:", "blob:"],
          connectSrc: ["'self'"],
          fontSrc: ["'self'"],
          objectSrc: ["'none'"],
          mediaSrc: ["'self'"],
          frameSrc: ["'none'"],
        },
      },
      crossOriginOpenerPolicy: { policy: "cross-origin" }
    }));

    // Set up the main server routes
    console.log('🔧 Setting up server routes...');
    await setupServer(app);

    // Serve static files from multiple potential locations
    const staticPaths = [
      path.join(__dirname, 'dist'),
      path.join(__dirname, 'client', 'dist'),
      path.join(__dirname, 'public')
    ];

    for (const staticPath of staticPaths) {
      if (fs.existsSync(staticPath)) {
        console.log(`📁 Serving static files from: ${staticPath}`);
        app.use(express.static(staticPath, {
          maxAge: isProduction ? '1d' : '0',
          etag: false,
          lastModified: false
        }));
        break;
      }
    }

    // Health check endpoint
    app.get('/health', (req, res) => {
      res.json({ 
        status: 'ok', 
        timestamp: new Date().toISOString(),
        environment: process.env.NODE_ENV,
        version: '1.0.0'
      });
    });

    // Catch-all handler for SPA
    app.get('*', (req, res) => {
      // Don't interfere with API routes
      if (req.path.startsWith('/api/')) {
        return res.status(404).json({ message: 'API endpoint not found' });
      }

      // Find and serve index.html
      const indexPaths = [
        path.join(__dirname, 'dist', 'index.html'),
        path.join(__dirname, 'client', 'dist', 'index.html'),
        path.join(__dirname, 'public', 'index.html')
      ];

      for (const indexPath of indexPaths) {
        if (fs.existsSync(indexPath)) {
          return res.sendFile(indexPath);
        }
      }

      res.status(404).send('Application not found');
    });

    // Global error handler for download issues
    app.use((error, req, res, next) => {
      console.error('🚨 Server error:', error);
      
      // Special handling for download errors
      if (req.url.includes('/download')) {
        return res.status(500).json({
          message: 'Download failed',
          details: 'Unable to process file download request'
        });
      }

      if (isProduction) {
        res.status(500).json({ message: 'Internal server error' });
      } else {
        res.status(500).json({ 
          message: error.message,
          stack: error.stack
        });
      }
    });

    // Start the server
    const server = app.listen(port, '0.0.0.0', () => {
      console.log('✅ VPS Server started successfully!');
      console.log(`🌐 Server running on: http://0.0.0.0:${port}`);
      console.log(`📂 Working directory: ${process.cwd()}`);
      console.log(`🔒 HTTPS support: ${process.env.HTTPS_ENABLED || 'disabled'}`);
      
      // Log upload directory status
      const uploadDirs = [
        path.join(process.cwd(), 'uploads'),
        '/var/www/html/uploads',
        '/home/user/public_html/uploads'
      ];
      
      console.log('📁 Upload directory status:');
      uploadDirs.forEach(dir => {
        const exists = fs.existsSync(dir);
        console.log(`   ${exists ? '✅' : '❌'} ${dir}`);
      });
    });

    // Graceful shutdown
    process.on('SIGTERM', () => {
      console.log('🛑 SIGTERM received, shutting down gracefully...');
      server.close(() => {
        console.log('👋 Process terminated');
        process.exit(0);
      });
    });

    process.on('SIGINT', () => {
      console.log('🛑 SIGINT received, shutting down gracefully...');
      server.close(() => {
        console.log('👋 Process terminated');
        process.exit(0);
      });
    });

    // Handle uncaught exceptions
    process.on('uncaughtException', (error) => {
      console.error('🚨 Uncaught Exception:', error);
      console.log('🛑 Shutting down due to uncaught exception...');
      process.exit(1);
    });

    process.on('unhandledRejection', (reason, promise) => {
      console.error('🚨 Unhandled Rejection at:', promise, 'reason:', reason);
      console.log('🛑 Shutting down due to unhandled rejection...');
      process.exit(1);
    });

  } catch (error) {
    console.error('❌ Failed to start VPS server:', error);
    process.exit(1);
  }
}

// Start the VPS server
startVPSServer().catch(error => {
  console.error('❌ Critical startup error:', error);
  process.exit(1);
});