#!/bin/bash

echo "=== VPS Server Diagnostics ==="

# Check if Node.js is installed
echo "Node.js Version:"
node --version || echo "❌ Node.js not installed"

# Check if server is running on port 5000
echo -e "\nChecking port 5000:"
ss -tulnp | grep :5000 || echo "❌ Port 5000 not in use"

# Check PM2 status
echo -e "\nPM2 Status:"
pm2 status || echo "❌ PM2 not available"

# Check for Node processes
echo -e "\nNode Processes:"
ps aux | grep node | grep -v grep || echo "❌ No Node processes running"

# Check if server file exists
echo -e "\nServer Files:"
ls -la start-production-vps.cjs || echo "❌ Server file missing"

# Check package.json
echo -e "\nPackage Info:"
ls -la package*.json || echo "❌ Package files missing"

# Check recent logs
echo -e "\nRecent System Logs (last 10 lines):"
tail -10 /var/log/messages 2>/dev/null || tail -10 /var/log/syslog 2>/dev/null || echo "❌ Cannot access system logs"

echo -e "\n=== End Diagnostics ==="