# VPS Server Connection Refused - Complete Fix Guide

## Problem Analysis
Your Apache proxy is trying to connect to `localhost:5000` but getting "Connection refused", which means:
- Apache is configured correctly
- Node.js application is NOT running on port 5000

## Immediate Diagnosis

### Step 1: Run Diagnostics
```bash
chmod +x check-server-status.sh
./check-server-status.sh
```

### Step 2: Check What's Actually Running
```bash
# Check if anything is on port 5000
netstat -tlnp | grep :5000

# Check all Node processes
ps aux | grep node
```

## Startup Solutions

### Method 1: Automated Startup Script
```bash
chmod +x start-server-multiple-ways.sh
./start-server-multiple-ways.sh
```

### Method 2: Manual PM2 Startup
```bash
# Stop everything first
pm2 stop all
pm2 delete all

# Start fresh
pm2 start start-production-vps.cjs --name "tender247"
pm2 status
pm2 logs
```

### Method 3: Direct Node Startup
```bash
# Run in background
nohup node start-production-vps.cjs > server.log 2>&1 &

# Check if running
ps aux | grep start-production-vps
tail -f server.log
```

## Common Issues & Fixes

### Issue 1: Node.js Not Installed
```bash
# Install Node.js 18+
curl -fsSL https://rpm.nodesource.com/setup_18.x | sudo bash -
sudo yum install -y nodejs
```

### Issue 2: Dependencies Missing
```bash
npm install
```

### Issue 3: Port 5000 Already in Use
```bash
# Find what's using port 5000
sudo lsof -i :5000

# Kill the process (replace PID)
sudo kill -9 PID_NUMBER
```

### Issue 4: Database Connection Failed
```bash
# Check if PostgreSQL is running
sudo systemctl status postgresql

# Start PostgreSQL if needed
sudo systemctl start postgresql
```

### Issue 5: Environment Variables Missing
```bash
# Create .env file with your database credentials
cat > .env << EOF
DATABASE_URL=postgresql://username:password@localhost:5432/tender247
NODE_ENV=production
PORT=5000
JWT_SECRET=your-jwt-secret
EOF
```

## Verification Steps

### 1. Confirm Server is Running
```bash
curl http://localhost:5000
# Should return HTML or JSON, not "Connection refused"
```

### 2. Check Apache Proxy
```bash
# Test the proxy connection
curl http://your-domain.com
```

### 3. Monitor Logs
```bash
# PM2 logs
pm2 logs

# Apache error logs
sudo tail -f /var/log/httpd/error_log
```

## Success Indicators
✅ `netstat -tlnp | grep :5000` shows Node.js listening
✅ `pm2 status` shows "online" status
✅ `curl localhost:5000` returns website content
✅ Apache proxy works without "Connection refused"

## If Still Not Working
1. Check server resource usage: `free -h` and `df -h`
2. Verify file permissions: `ls -la start-production-vps.cjs`
3. Check for firewall issues: `sudo iptables -L`
4. Review system logs: `sudo journalctl -f`

The root cause is that your Node.js application isn't starting properly, not a proxy configuration issue.