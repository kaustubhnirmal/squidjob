#!/usr/bin/env node

/**
 * VPS Production Startup Script - CommonJS Version
 * Handles Node.js module system compatibility issues on VPS
 * Optimized for VPS deployment with HTTP/2 download fixes
 */

const express = require('express');
const path = require('path');
const fs = require('fs');
const cors = require('cors');
const helmet = require('helmet');

// Configuration
const isProduction = process.env.NODE_ENV === 'production';
const port = process.env.PORT || 5000;

console.log('='.repeat(50));
console.log('🚀 Tender Management System - VPS Mode');
console.log('='.repeat(50));
console.log(`📡 Port: ${port}`);
console.log(`🌍 Environment: ${process.env.NODE_ENV || 'development'}`);
console.log(`📦 Node.js: ${process.version}`);
console.log(`📁 Directory: ${process.cwd()}`);

async function startVPSServer() {
  try {
    const app = express();

    // VPS-specific middleware for download compatibility
    app.use((req, res, next) => {
      // Force HTTP/1.1 for file downloads to avoid HTTP/2 protocol errors
      if (req.url.includes('/download')) {
        console.log(`📥 Download request: ${req.method} ${req.url}`);
        res.setHeader('Connection', 'close');
        res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
        res.setHeader('Pragma', 'no-cache');
        res.setHeader('Expires', '0');
      }
      next();
    });

    // Enhanced CORS for VPS deployment
    app.use(cors({
      origin: [
        'https://squidjob.com',
        'http://squidjob.com',
        'https://www.squidjob.com',
        'http://www.squidjob.com',
        `http://localhost:${port}`,
        `https://localhost:${port}`,
        /\.squidjob\.com$/
      ],
      credentials: true,
      methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS', 'PATCH'],
      allowedHeaders: [
        'Origin', 
        'X-Requested-With', 
        'Content-Type', 
        'Accept', 
        'Authorization',
        'x-user-id',
        'Cache-Control'
      ],
      exposedHeaders: [
        'Content-Disposition',
        'Content-Length',
        'Content-Type'
      ]
    }));

    // Security headers - VPS compatible (disable problematic policies)
    app.use(helmet({
      crossOriginEmbedderPolicy: false,
      crossOriginOpenerPolicy: false,
      crossOriginResourcePolicy: false,
      contentSecurityPolicy: false
    }));

    // Body parsing middleware
    app.use(express.json({ limit: '50mb' }));
    app.use(express.urlencoded({ extended: true, limit: '50mb' }));

    // Try to load the main application with fallback
    let appLoaded = false;

    // Method 1: Try to load existing compiled server
    try {
      if (fs.existsSync(path.join(__dirname, 'dist', 'server', 'index.js'))) {
        console.log('📦 Loading compiled server...');
        const serverModule = require('./dist/server/index.js');
        const setupServer = serverModule.setupServer || serverModule.default?.setupServer;
        if (setupServer) {
          await setupServer(app);
          appLoaded = true;
          console.log('✅ Compiled server loaded successfully');
        }
      }
    } catch (error) {
      console.log('⚠️ Compiled server not available:', error.message);
    }

    // Method 2: Try to load server.js
    if (!appLoaded) {
      try {
        if (fs.existsSync(path.join(__dirname, 'server.js'))) {
          console.log('📦 Loading server.js...');
          const serverModule = require('./server.js');
          const setupServer = serverModule.setupServer || serverModule.default?.setupServer || serverModule;
          if (typeof setupServer === 'function') {
            await setupServer(app);
            appLoaded = true;
            console.log('✅ server.js loaded successfully');
          }
        }
      } catch (error) {
        console.log('⚠️ server.js not available:', error.message);
      }
    }

    // Method 3: Try TypeScript with tsx
    if (!appLoaded) {
      try {
        console.log('📦 Attempting TypeScript with tsx...');
        const tsx = require('tsx/cjs');
        tsx.register();
        const serverModule = require('./server/index.ts');
        const setupServer = serverModule.setupServer || serverModule.default?.setupServer;
        if (setupServer) {
          await setupServer(app);
          appLoaded = true;
          console.log('✅ TypeScript server loaded with tsx');
        }
      } catch (error) {
        console.log('⚠️ tsx not available:', error.message);
      }
    }

    // Method 4: Try with ts-node
    if (!appLoaded) {
      try {
        console.log('📦 Attempting TypeScript with ts-node...');
        require('ts-node/register');
        const serverModule = require('./server/index.ts');
        const setupServer = serverModule.setupServer || serverModule.default?.setupServer;
        if (setupServer) {
          await setupServer(app);
          appLoaded = true;
          console.log('✅ TypeScript server loaded with ts-node');
        }
      } catch (error) {
        console.log('⚠️ ts-node not available:', error.message);
      }
    }

    // Fallback: Basic server setup
    if (!appLoaded) {
      console.log('📦 Using fallback server configuration...');
      
      // Health check endpoint
      app.get('/api/health', (req, res) => {
        res.json({ 
          status: 'ok', 
          message: 'VPS server running in fallback mode',
          timestamp: new Date().toISOString(),
          version: '1.0.0-vps'
        });
      });

      // Basic API endpoint for testing
      app.get('/api/test', (req, res) => {
        res.json({ 
          message: 'VPS server is working',
          environment: process.env.NODE_ENV,
          nodeVersion: process.version
        });
      });

      console.log('⚠️ Running in fallback mode - limited functionality');
    }

    // Serve static files from multiple potential locations
    const staticPaths = [
      path.join(__dirname, 'dist'),
      path.join(__dirname, 'client', 'dist'),
      path.join(__dirname, 'public'),
      path.join(__dirname, 'build')
    ];

    let staticServed = false;
    for (const staticPath of staticPaths) {
      if (fs.existsSync(staticPath)) {
        console.log(`📁 Serving static files from: ${staticPath}`);
        app.use(express.static(staticPath, {
          maxAge: isProduction ? '1d' : '0',
          etag: false,
          lastModified: false
        }));
        staticServed = true;
        break;
      }
    }

    if (!staticServed) {
      console.log('⚠️ No static files directory found');
    }

    // Catch-all handler for SPA
    app.get('*', (req, res) => {
      // Don't interfere with API routes
      if (req.path.startsWith('/api/')) {
        return res.status(404).json({ message: 'API endpoint not found' });
      }

      // Find and serve index.html
      const indexPaths = [
        path.join(__dirname, 'dist', 'index.html'),
        path.join(__dirname, 'client', 'dist', 'index.html'),
        path.join(__dirname, 'public', 'index.html'),
        path.join(__dirname, 'build', 'index.html')
      ];

      for (const indexPath of indexPaths) {
        if (fs.existsSync(indexPath)) {
          return res.sendFile(path.resolve(indexPath));
        }
      }

      res.status(404).send(`
        <html>
          <head><title>Application Not Found</title></head>
          <body>
            <h1>Tender Management System</h1>
            <p>VPS server is running but frontend files not found.</p>
            <p>Please ensure the application is properly built and deployed.</p>
            <hr>
            <small>Server: ${req.headers.host} | Time: ${new Date().toISOString()}</small>
          </body>
        </html>
      `);
    });

    // Global error handler
    app.use((error, req, res, next) => {
      console.error('🚨 Server error:', error.message);
      
      // Special handling for download errors
      if (req.url.includes('/download')) {
        return res.status(500).json({
          message: 'Download failed',
          details: 'Unable to process file download request'
        });
      }

      const errorResponse = {
        message: 'Internal server error',
        timestamp: new Date().toISOString()
      };

      if (!isProduction) {
        errorResponse.details = error.message;
        errorResponse.stack = error.stack;
      }

      res.status(500).json(errorResponse);
    });

    // Start the server
    const server = app.listen(port, '0.0.0.0', () => {
      console.log('='.repeat(50));
      console.log('✅ VPS Server Started Successfully!');
      console.log('='.repeat(50));
      console.log(`🌐 URL: http://0.0.0.0:${port}`);
      console.log(`📂 Working Directory: ${process.cwd()}`);
      console.log(`🔧 Application Loaded: ${appLoaded ? 'Yes' : 'Fallback Mode'}`);
      console.log(`📁 Static Files: ${staticServed ? 'Served' : 'Not Found'}`);
      
      // Log upload directory status
      const uploadDirs = [
        path.join(process.cwd(), 'uploads'),
        '/var/www/html/uploads',
        '/home/user/public_html/uploads'
      ];
      
      console.log('📁 Upload Directory Status:');
      uploadDirs.forEach(dir => {
        const exists = fs.existsSync(dir);
        console.log(`   ${exists ? '✅' : '❌'} ${dir}`);
      });
      
      console.log('='.repeat(50));
    });

    // Graceful shutdown handlers
    const shutdown = (signal) => {
      console.log(`🛑 ${signal} received, shutting down gracefully...`);
      server.close(() => {
        console.log('👋 Server closed');
        process.exit(0);
      });
    };

    process.on('SIGTERM', () => shutdown('SIGTERM'));
    process.on('SIGINT', () => shutdown('SIGINT'));

    // Handle uncaught exceptions
    process.on('uncaughtException', (error) => {
      console.error('🚨 Uncaught Exception:', error.message);
      console.error(error.stack);
      process.exit(1);
    });

    process.on('unhandledRejection', (reason, promise) => {
      console.error('🚨 Unhandled Rejection:', reason);
      process.exit(1);
    });

  } catch (error) {
    console.error('❌ Failed to start VPS server:', error.message);
    console.error(error.stack);
    process.exit(1);
  }
}

// Start the server
console.log('🔄 Initializing VPS server...');
startVPSServer().catch(error => {
  console.error('❌ Critical startup error:', error.message);
  process.exit(1);
});