#!/bin/bash

echo "=== Multiple Server Startup Methods ==="

# Stop any running servers first
echo "1. Stopping existing servers..."
pm2 stop all 2>/dev/null || echo "No PM2 processes to stop"
pkill -f "start-production-vps" 2>/dev/null || echo "No server processes to kill"

# Method 1: PM2 startup
echo -e "\n2. Trying PM2 startup..."
if command -v pm2 &> /dev/null; then
    pm2 start start-production-vps.cjs --name "tender247"
    sleep 3
    pm2 status
    if pm2 list | grep -q "tender247.*online"; then
        echo "✅ PM2 startup successful"
        exit 0
    else
        echo "❌ PM2 startup failed"
        pm2 logs --lines 5
    fi
else
    echo "❌ PM2 not installed"
fi

# Method 2: Direct Node startup
echo -e "\n3. Trying direct Node startup..."
if command -v node &> /dev/null; then
    echo "Starting server with Node.js..."
    nohup node start-production-vps.cjs > server.log 2>&1 &
    SERVER_PID=$!
    echo "Server PID: $SERVER_PID"
    sleep 5
    
    # Check if process is still running
    if kill -0 $SERVER_PID 2>/dev/null; then
        echo "✅ Direct Node startup successful (PID: $SERVER_PID)"
        echo "Check server.log for details"
        tail -5 server.log
        exit 0
    else
        echo "❌ Direct Node startup failed"
        echo "Error log:"
        cat server.log
    fi
else
    echo "❌ Node.js not available"
fi

# Method 3: npm start (if package.json exists)
echo -e "\n4. Trying npm start..."
if [ -f "package.json" ]; then
    npm start &
    NPM_PID=$!
    sleep 5
    if kill -0 $NPM_PID 2>/dev/null; then
        echo "✅ npm start successful (PID: $NPM_PID)"
        exit 0
    else
        echo "❌ npm start failed"
    fi
else
    echo "❌ package.json not found"
fi

echo -e "\n❌ All startup methods failed"
echo "Please check the diagnostics and error logs above"