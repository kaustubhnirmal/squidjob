#!/bin/bash

# VPS Download Fix Deployment Script
# Tender Management System - squidjob.com
# This script deploys the HTTP/2 protocol error fix for PDF downloads

echo "🚀 Starting VPS Download Fix Deployment..."
echo "=================================================="

# Set script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP_DIR="${1:-/home/$(whoami)/public_html}"

echo "📁 Deployment directory: $APP_DIR"
echo "📁 Script directory: $SCRIPT_DIR"

# Function to backup existing files
backup_files() {
    echo "💾 Creating backup of existing files..."
    BACKUP_DIR="$APP_DIR/backup-$(date +%Y%m%d-%H%M%S)"
    mkdir -p "$BACKUP_DIR"
    
    # Backup important files
    if [ -f "$APP_DIR/server/routes.ts" ]; then
        cp "$APP_DIR/server/routes.ts" "$BACKUP_DIR/"
        echo "✅ Backed up routes.ts"
    fi
    
    if [ -f "$APP_DIR/start-production.js" ]; then
        cp "$APP_DIR/start-production.js" "$BACKUP_DIR/"
        echo "✅ Backed up start-production.js"
    fi
    
    echo "💾 Backup created at: $BACKUP_DIR"
}

# Function to deploy new files
deploy_files() {
    echo "📦 Deploying updated files..."
    
    # Copy new production starter (CommonJS version)
    if [ -f "$SCRIPT_DIR/start-production-vps.cjs" ]; then
        cp "$SCRIPT_DIR/start-production-vps.cjs" "$APP_DIR/"
        chmod +x "$APP_DIR/start-production-vps.cjs"
        echo "✅ Deployed start-production-vps.cjs"
    fi
    
    # Copy VPS-compatible package.json
    if [ -f "$SCRIPT_DIR/package-vps.json" ]; then
        cp "$SCRIPT_DIR/package-vps.json" "$APP_DIR/package-vps.json"
        echo "✅ Deployed VPS package.json"
    fi
    
    # Copy fallback JS version if available
    if [ -f "$SCRIPT_DIR/start-production-vps.js" ]; then
        cp "$SCRIPT_DIR/start-production-vps.js" "$APP_DIR/"
        chmod +x "$APP_DIR/start-production-vps.js"
        echo "✅ Deployed start-production-vps.js (fallback)"
    fi
    
    # Copy updated routes.ts if it exists
    if [ -f "$SCRIPT_DIR/server/routes.ts" ]; then
        cp "$SCRIPT_DIR/server/routes.ts" "$APP_DIR/server/"
        echo "✅ Deployed updated routes.ts"
    fi
    
    # Copy documentation
    if [ -f "$SCRIPT_DIR/VPS_DOWNLOAD_FIX_GUIDE.md" ]; then
        cp "$SCRIPT_DIR/VPS_DOWNLOAD_FIX_GUIDE.md" "$APP_DIR/"
        echo "✅ Deployed documentation"
    fi
}

# Function to setup upload directories
setup_directories() {
    echo "📁 Setting up upload directories..."
    
    # Create uploads directory if it doesn't exist
    UPLOAD_DIRS=(
        "$APP_DIR/uploads"
        "/var/www/html/uploads"
        "/home/$(whoami)/public_html/uploads"
    )
    
    for DIR in "${UPLOAD_DIRS[@]}"; do
        if [ ! -d "$DIR" ] && [[ "$DIR" == *"$APP_DIR"* ]]; then
            mkdir -p "$DIR"
            chmod 755 "$DIR"
            echo "✅ Created directory: $DIR"
        elif [ -d "$DIR" ]; then
            chmod 755 "$DIR"
            echo "✅ Updated permissions: $DIR"
        fi
    done
}

# Function to install dependencies
install_dependencies() {
    echo "📦 Installing/updating dependencies..."
    cd "$APP_DIR"
    
    if [ -f "package.json" ]; then
        # Check if npm is available
        if command -v npm &> /dev/null; then
            npm install --production
            echo "✅ Dependencies installed"
        else
            echo "⚠️  npm not found, skipping dependency installation"
        fi
    else
        echo "⚠️  package.json not found, skipping dependency installation"
    fi
}

# Function to stop existing process
stop_existing() {
    echo "🛑 Stopping existing application..."
    
    # Try to stop PM2 process first
    if command -v pm2 &> /dev/null; then
        pm2 stop tender-management 2>/dev/null || true
        pm2 delete tender-management 2>/dev/null || true
        echo "✅ Stopped PM2 processes"
    fi
    
    # Kill any node processes running on port 5000
    lsof -ti:5000 | xargs kill -9 2>/dev/null || true
    echo "✅ Cleared port 5000"
}

# Function to start application
start_application() {
    echo "🚀 Starting application with VPS optimizations..."
    cd "$APP_DIR"
    
    # Set environment variables
    export NODE_ENV=production
    export PORT=${PORT:-5000}
    
    # Try CommonJS version first
    if [ -f "start-production-vps.cjs" ]; then
        STARTUP_FILE="start-production-vps.cjs"
        echo "✅ Using CommonJS version for VPS compatibility"
    elif [ -f "start-production-vps.js" ]; then
        STARTUP_FILE="start-production-vps.js"
        echo "✅ Using JavaScript version"
    else
        echo "❌ No VPS startup file found"
        return 1
    fi
    
    if command -v pm2 &> /dev/null; then
        # Start with PM2
        pm2 start "$STARTUP_FILE" --name "tender-management" --env production
        pm2 save
        echo "✅ Started with PM2 using $STARTUP_FILE"
        echo "📊 View logs: pm2 logs tender-management"
        echo "📈 View status: pm2 status"
    else
        # Start directly (background)
        nohup node "$STARTUP_FILE" > app.log 2>&1 &
        echo "✅ Started in background using $STARTUP_FILE"
        echo "📊 View logs: tail -f $APP_DIR/app.log"
    fi
}

# Function to verify deployment
verify_deployment() {
    echo "🔍 Verifying deployment..."
    
    # Wait a moment for startup
    sleep 3
    
    # Check if process is running
    if pgrep -f "start-production-vps.js" > /dev/null; then
        echo "✅ Application process is running"
    else
        echo "❌ Application process not found"
        return 1
    fi
    
    # Check if port is listening
    if netstat -tulpn 2>/dev/null | grep ":5000 " > /dev/null; then
        echo "✅ Application is listening on port 5000"
    else
        echo "❌ Port 5000 not listening"
        return 1
    fi
    
    # Try to make a health check request
    if command -v curl &> /dev/null; then
        if curl -s http://localhost:5000/health > /dev/null; then
            echo "✅ Health check passed"
        else
            echo "⚠️  Health check failed (but application may still be starting)"
        fi
    fi
    
    return 0
}

# Main deployment flow
main() {
    echo "Starting deployment process..."
    
    # Check if we're in the right directory
    if [ ! -f "$SCRIPT_DIR/start-production-vps.js" ]; then
        echo "❌ Required files not found. Make sure you're running from the correct directory."
        exit 1
    fi
    
    # Confirm deployment
    echo "This will deploy the VPS download fix to: $APP_DIR"
    read -p "Continue? (y/N): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        echo "Deployment cancelled."
        exit 0
    fi
    
    # Execute deployment steps
    backup_files
    stop_existing
    deploy_files
    setup_directories
    install_dependencies
    start_application
    
    if verify_deployment; then
        echo ""
        echo "🎉 DEPLOYMENT SUCCESSFUL!"
        echo "=================================================="
        echo "🌐 Application URL: https://squidjob.com"
        echo "🔧 Admin Panel: https://squidjob.com/admin"
        echo "📥 Downloads should now work without HTTP/2 errors"
        echo ""
        echo "📊 Monitor your application:"
        if command -v pm2 &> /dev/null; then
            echo "   pm2 logs tender-management"
            echo "   pm2 monit"
        else
            echo "   tail -f $APP_DIR/app.log"
        fi
        echo ""
        echo "🔧 If issues persist, check the troubleshooting guide:"
        echo "   cat $APP_DIR/VPS_DOWNLOAD_FIX_GUIDE.md"
    else
        echo ""
        echo "⚠️  DEPLOYMENT COMPLETED WITH WARNINGS"
        echo "Application may still be starting up."
        echo "Check logs for any issues:"
        if command -v pm2 &> /dev/null; then
            echo "   pm2 logs tender-management"
        else
            echo "   tail -f $APP_DIR/app.log"
        fi
    fi
}

# Run main function
main "$@"