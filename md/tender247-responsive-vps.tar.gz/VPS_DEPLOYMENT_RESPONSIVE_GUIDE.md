# VPS Deployment Guide - Responsive Design Update

## Overview
This package contains the Tender Management System with responsive design improvements for mobile-first user experience.

## What's New in This Version
- ✅ **Mobile-First Design**: All tender listing pages now work perfectly on mobile devices
- ✅ **Responsive Tabs**: Tab navigation adapts to smaller screens
- ✅ **Improved Card Layouts**: Tender cards stack neatly on mobile with better readability
- ✅ **Optimized Document Links**: Document download buttons are properly sized for touch interfaces
- ✅ **Better Typography**: Font sizes and spacing optimized for all screen sizes

## Updated Pages
1. **All Tenders Page** (`/tenders`) - Fully responsive with mobile-first layout
2. **My Tenders Page** (`/my-tenders`) - Optimized for mobile viewing and interaction

## Deployment Instructions

### Step 1: Upload Files to VPS
Upload the entire `vps-deployment-responsive` folder to your VPS server:
```bash
scp -r vps-deployment-responsive/ root@your-server-ip:/var/www/html/tender247-responsive/
```

### Step 2: Navigate to Project Directory
```bash
cd /var/www/html/tender247-responsive/
```

### Step 3: Install Dependencies
```bash
npm install
```

### Step 4: Set Environment Variables
Create `.env` file with your database credentials:
```bash
nano .env
```

Add your database connection details:
```
DATABASE_URL=postgresql://username:password@localhost:5432/tender247
NODE_ENV=production
JWT_SECRET=your-jwt-secret-here
PORT=5000
```

### Step 5: Run Database Migration (if needed)
```bash
npm run db:push
```

### Step 6: Start the Application
```bash
npm start
```

Or use PM2 for process management:
```bash
pm2 start start-production-vps.cjs --name "tender247-responsive"
pm2 save
pm2 startup
```

### Step 7: Configure Nginx (Optional)
Create nginx configuration for reverse proxy:
```bash
nano /etc/nginx/sites-available/tender247-responsive
```

Add configuration:
```nginx
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
```

Enable the site:
```bash
ln -s /etc/nginx/sites-available/tender247-responsive /etc/nginx/sites-enabled/
nginx -t
systemctl reload nginx
```

## Testing Responsive Design

### Desktop Testing
- Open browser and navigate to your application
- Check that all pages load correctly
- Verify full functionality on large screens

### Mobile Testing
1. **Browser Developer Tools**:
   - Open Chrome/Firefox Developer Tools
   - Toggle device simulation
   - Test with various mobile screen sizes (iPhone, Android)

2. **Real Device Testing**:
   - Access the application from your mobile phone
   - Test navigation, scrolling, and button interactions
   - Verify that all text is readable without zooming

### Key Areas to Test
- ✅ Tender listing pages (All Tenders, My Tenders)
- ✅ Tab navigation responsiveness
- ✅ Document download buttons
- ✅ Search and filter functionality
- ✅ Action buttons (Star, Interest, etc.)

## Responsive Design Features

### Mobile Optimizations
- **Grid Layouts**: Information is organized in mobile-friendly grids
- **Touch-Friendly**: Buttons and links are properly sized for touch
- **Readable Text**: Font sizes adjust for optimal mobile reading
- **Compact Design**: Better use of screen space on small devices

### Screen Breakpoints
- **Small (sm)**: 640px and up - Tablet portrait
- **Medium (md)**: 768px and up - Tablet landscape  
- **Large (lg)**: 1024px and up - Desktop
- **Extra Large (xl)**: 1280px and up - Large desktop

### CSS Classes Used
- `sm:text-sm` - Smaller text on mobile, normal on tablet+
- `flex-col sm:flex-row` - Stack vertically on mobile, horizontal on tablet+
- `gap-1 sm:gap-2` - Smaller gaps on mobile, larger on tablet+
- `px-3 sm:px-4` - Less padding on mobile, more on tablet+

## Troubleshooting

### Common Issues
1. **Layout Issues**: Clear browser cache and check CSS loading
2. **Button Problems**: Verify touch event handling works properly
3. **Text Too Small**: Check that responsive font classes are applied
4. **Navigation Issues**: Test tab switching on different screen sizes

### Performance Tips
- Enable gzip compression in nginx
- Optimize images for mobile bandwidth
- Monitor application performance on mobile networks
- Consider implementing caching strategies

## Support
If you encounter any issues with the responsive design:
1. Check browser console for errors
2. Test with different devices and browsers
3. Verify that all CSS files are loading correctly
4. Contact support with specific device and browser information

## Files Modified for Responsive Design
- `client/src/pages/tenders.tsx` - All Tenders page responsive layout
- `client/src/pages/my-tenders.tsx` - My Tenders page responsive layout
- Updated tab navigation components
- Enhanced mobile-first CSS classes

This responsive version ensures your Tender Management System works seamlessly across all devices, providing an excellent user experience for both desktop and mobile users.